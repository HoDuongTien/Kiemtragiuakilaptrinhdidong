﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.Models
{
    public class Device
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string DeviceName { get; set; } = "";

        public string? DeviceModel { get; set; }

        public int ChildId { get; set; }

        public Child Child { get; set; } = null!;

        public DateTime CreatedAt { get; set; }
            = DateTime.UtcNow;
    }
}
