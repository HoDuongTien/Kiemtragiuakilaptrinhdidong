﻿
namespace hoduongtien_2219.Models
{
    public class TimeRequest
    {
        public int Id { get; set; }

        public int ChildId { get; set; }

        public Child Child { get; set; } = null!;

        public int RequestedMinutes { get; set; }

        public string Reason { get; set; } = "";

        public string Status { get; set; } = "Pending";

        public DateTime CreatedAt { get; set; }
            = DateTime.UtcNow;
    }
}
