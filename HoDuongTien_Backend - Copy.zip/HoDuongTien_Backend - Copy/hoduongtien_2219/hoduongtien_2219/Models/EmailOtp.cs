﻿
namespace hoduongtien_2219.Models
{
    public class EmailOtp
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public AppUser User { get; set; } = null!;

        public string CodeHash { get; set; } = "";

        public DateTime ExpiresAt { get; set; }

        public bool IsUsed { get; set; } = false;

        public int FailedAttempts { get; set; } = 0;
    }
}
