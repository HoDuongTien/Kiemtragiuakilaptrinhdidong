﻿
namespace hoduongtien_2219.Models
{
    public class PairingCode
    {
        public int Id { get; set; }

        public int ChildId { get; set; }

        public Child Child { get; set; } = null!;

        public string CodeHash { get; set; } = "";

        public DateTime ExpiresAt { get; set; }

        public bool IsUsed { get; set; } = false;
    }
}
