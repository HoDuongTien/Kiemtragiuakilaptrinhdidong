﻿
namespace hoduongtien_2219.Models
{
    public class ScreenTimeRule
    {
        public int Id { get; set; }

        public int ChildId { get; set; }

        public Child Child { get; set; } = null!;

        public int DailyLimitMinutes { get; set; } = 120;

        public bool IsEnabled { get; set; } = true;
    }
}
