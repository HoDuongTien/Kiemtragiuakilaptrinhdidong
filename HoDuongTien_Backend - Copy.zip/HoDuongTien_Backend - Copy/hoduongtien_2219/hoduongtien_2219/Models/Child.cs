﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.Models
{
    public class Child
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; } = "";

        public DateTime? DateOfBirth { get; set; }

        public string? Gender { get; set; }

        public int ParentId { get; set; }

        public AppUser Parent { get; set; } = null!;

        public int? ChildUserId { get; set; }

        public AppUser? ChildUser { get; set; }
    }
}
