﻿
namespace hoduongtien_2219.Models
{
    public class ChildLocation
    {
        public int Id { get; set; }

        public int ChildId { get; set; }

        public Child Child { get; set; } = null!;

        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public DateTime RecordedAt { get; set; }
            = DateTime.UtcNow;
    }
}
