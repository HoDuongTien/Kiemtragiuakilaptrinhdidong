﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.Models
{
    public class AppUser
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; } = "";

        [Required, EmailAddress, MaxLength(255)]
        public string Email { get; set; } = "";

        [Required]
        public string PasswordHash { get; set; } = "";

        [Required, MaxLength(20)]
        public string Role { get; set; } = "Parent";

        public DateTime CreatedAt { get; set; }
            = DateTime.UtcNow;
    }
}
