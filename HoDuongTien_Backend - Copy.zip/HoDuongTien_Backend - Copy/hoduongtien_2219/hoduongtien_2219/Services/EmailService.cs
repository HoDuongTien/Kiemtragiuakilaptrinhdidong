﻿
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace hoduongtien_2219.Services
{
    public class EmailService
    {
        private readonly IConfiguration _config;

        public EmailService(IConfiguration config)
        {
            _config = config;
        }

        public async Task SendOtpAsync(string toEmail, string otp)
        {
            var message = new MimeMessage();

            var fromEmail = _config["Email:Username"]
                ?? throw new InvalidOperationException(
                    "Chua cau hinh Email:Username");

            var password = _config["Email:AppPassword"]
                ?? throw new InvalidOperationException(
                    "Chua cau hinh Email:AppPassword");

            message.From.Add(
                MailboxAddress.Parse(fromEmail));

            message.To.Add(
                MailboxAddress.Parse(toEmail));

            message.Subject = "Ma OTP dang nhap KidSafe";

            message.Body = new TextPart("plain")
            {
                Text = $"Ma OTP cua ban la: {otp}. " +
                       "Ma co hieu luc trong 5 phut."
            };

            using var client = new SmtpClient();

            await client.ConnectAsync(
                "smtp.gmail.com",
                587,
                SecureSocketOptions.StartTls);

            await client.AuthenticateAsync(
                fromEmail,
                password);

            await client.SendAsync(message);

            await client.DisconnectAsync(true);
        }
    }
}
