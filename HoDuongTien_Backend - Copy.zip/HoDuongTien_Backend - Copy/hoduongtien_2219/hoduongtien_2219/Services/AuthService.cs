﻿
using System.Security.Cryptography;
using System.Text;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories.Interfaces;
using Microsoft.AspNetCore.Identity;

namespace hoduongtien_2219.Services
{
    public class AuthService
    {
        private readonly IUserRepository _users;
        private readonly IEmailOtpRepository _otps;
        private readonly EmailService _email;
        private readonly JwtService _jwt;
        private readonly IPasswordHasher<AppUser> _passwordHasher;

        public AuthService(
            IUserRepository users,
            IEmailOtpRepository otps,
            EmailService email,
            JwtService jwt,
            IPasswordHasher<AppUser> passwordHasher)
        {
            _users = users;
            _otps = otps;
            _email = email;
            _jwt = jwt;
            _passwordHasher = passwordHasher;
        }

        public async Task<(bool Success, string Message)> RegisterAsync(
            RegisterDto dto)
        {
            var email = dto.Email.Trim().ToLowerInvariant();

            if (await _users.GetByEmailAsync(email) != null)
                return (false, "Email da duoc su dung.");

            var user = new AppUser
            {
                FullName = dto.FullName.Trim(),
                Email = email,
                Role = "Parent"
            };

            user.PasswordHash =
                _passwordHasher.HashPassword(user, dto.Password);

            await _users.AddAsync(user);

            return (true, "Dang ky thanh cong.");
        }

        public async Task<(bool Success, string Message)> LoginAsync(
            LoginDto dto)
        {
            var email = dto.Email.Trim().ToLowerInvariant();
            var user = await _users.GetByEmailAsync(email);

            if (user == null)
                return (false, "Email hoac mat khau khong dung.");

            var result = _passwordHasher.VerifyHashedPassword(
                user, user.PasswordHash, dto.Password);

            if (result == PasswordVerificationResult.Failed)
                return (false, "Email hoac mat khau khong dung.");

            var otp = RandomNumberGenerator
                .GetInt32(100000, 1000000)
                .ToString();

            var otpRecord = new EmailOtp
            {
                UserId = user.Id,
                CodeHash = HashOtp(otp),
                ExpiresAt = DateTime.UtcNow.AddMinutes(5),
                IsUsed = false,
                FailedAttempts = 0
            };

            await _otps.AddAsync(otpRecord);

            await _email.SendOtpAsync(user.Email, otp);

            return (true, "Ma OTP da duoc gui den email.");
        }

        public async Task<(bool Success, string Message, object? Data)>
            VerifyOtpAsync(VerifyOtpDto dto)
        {
            var email = dto.Email.Trim().ToLowerInvariant();
            var user = await _users.GetByEmailAsync(email);

            if (user == null)
                return (false, "OTP khong hop le.", null);

            var otpRecord =
                await _otps.GetLatestValidOtpAsync(user.Id);

            if (otpRecord == null)
                return (false, "OTP khong hop le hoac da het han.", null);

            if (otpRecord.FailedAttempts >= 5)
                return (false, "OTP da vuot qua so lan thu.", null);

            if (!CryptographicOperations.FixedTimeEquals(
                    Convert.FromHexString(otpRecord.CodeHash),
                    Convert.FromHexString(HashOtp(dto.OtpCode))))
            {
                otpRecord.FailedAttempts++;
                await _otps.UpdateAsync(otpRecord);

                return (false, "OTP khong dung.", null);
            }

            otpRecord.IsUsed = true;
            await _otps.UpdateAsync(otpRecord);

            var token = _jwt.GenerateToken(user);

            var data = new
            {
                Token = token,
                UserId = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                Role = user.Role
            };

            return (true, "Dang nhap thanh cong.", data);
        }

        private static string HashOtp(string otp)
        {
            var bytes = SHA256.HashData(
                Encoding.UTF8.GetBytes(otp));

            return Convert.ToHexString(bytes);
        }
    }
}
