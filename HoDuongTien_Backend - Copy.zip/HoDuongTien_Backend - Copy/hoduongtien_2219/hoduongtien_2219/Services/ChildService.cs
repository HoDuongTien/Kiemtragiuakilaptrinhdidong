﻿
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories.Interfaces;

namespace hoduongtien_2219.Services
{
    public class ChildService
    {
        private readonly IChildRepository _childRepository;

        public ChildService(IChildRepository childRepository)
        {
            _childRepository = childRepository;
        }

        public async Task<IEnumerable<Child>> GetAllAsync(int parentId)
        {
            return await _childRepository.GetByParentIdAsync(parentId);
        }

        public async Task<Child?> GetByIdAsync(int id, int parentId)
        {
            var child = await _childRepository.GetByIdAsync(id);

            if (child == null || child.ParentId != parentId)
                return null;

            return child;
        }

        public async Task<Child> CreateAsync(
            CreateChildDto dto, int parentId)
        {
            var child = new Child
            {
                FullName = dto.FullName.Trim(),
                DateOfBirth = dto.DateOfBirth,
                Gender = dto.Gender,
                ParentId = parentId
            };

            await _childRepository.AddAsync(child);

            return child;
        }

        public async Task<bool> UpdateAsync(
            int id, UpdateChildDto dto, int parentId)
        {
            var child = await GetByIdAsync(id, parentId);

            if (child == null)
                return false;

            child.FullName = dto.FullName.Trim();
            child.DateOfBirth = dto.DateOfBirth;
            child.Gender = dto.Gender;

            await _childRepository.UpdateAsync(child);

            return true;
        }

        public async Task<bool> DeleteAsync(int id, int parentId)
        {
            var child = await GetByIdAsync(id, parentId);

            if (child == null)
                return false;

            await _childRepository.DeleteAsync(id);

            return true;
        }
    }
}
