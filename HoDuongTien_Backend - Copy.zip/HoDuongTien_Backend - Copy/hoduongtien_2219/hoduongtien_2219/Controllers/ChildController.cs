﻿
using System.Security.Claims;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Parent")]
    public class ChildController : ControllerBase
    {
        private readonly ChildService _childService;

        public ChildController(ChildService childService)
        {
            _childService = childService;
        }

        private int? GetParentId()
        {
            var value = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            return int.TryParse(value, out var id)
                ? id
                : null;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var parentId = GetParentId();

            if (parentId == null)
                return Unauthorized();

            var children = await _childService
                .GetAllAsync(parentId.Value);

            return Ok(children.Select(c => new
            {
                c.Id,
                c.FullName,
                c.DateOfBirth,
                c.Gender,
                c.ParentId
            }));
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var parentId = GetParentId();

            if (parentId == null)
                return Unauthorized();

            var child = await _childService
                .GetByIdAsync(id, parentId.Value);

            if (child == null)
                return NotFound();

            return Ok(new
            {
                child.Id,
                child.FullName,
                child.DateOfBirth,
                child.Gender,
                child.ParentId
            });
        }

        [HttpPost]
        public async Task<IActionResult> Create(
            [FromBody] CreateChildDto dto)
        {
            var parentId = GetParentId();

            if (parentId == null)
                return Unauthorized();

            var child = await _childService
                .CreateAsync(dto, parentId.Value);

            return CreatedAtAction(
                nameof(GetById),
                new { id = child.Id },
                new
                {
                    child.Id,
                    child.FullName,
                    child.DateOfBirth,
                    child.Gender,
                    child.ParentId
                });
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(
            int id, [FromBody] UpdateChildDto dto)
        {
            var parentId = GetParentId();

            if (parentId == null)
                return Unauthorized();

            var updated = await _childService.UpdateAsync(
                id, dto, parentId.Value);

            if (!updated)
                return NotFound();

            return Ok(new
            {
                message = "Cap nhat ho so tre thanh cong."
            });
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var parentId = GetParentId();

            if (parentId == null)
                return Unauthorized();

            var deleted = await _childService.DeleteAsync(
                id, parentId.Value);

            if (!deleted)
                return NotFound();

            return Ok(new
            {
                message = "Xoa ho so tre thanh cong."
            });
        }
    }
}
