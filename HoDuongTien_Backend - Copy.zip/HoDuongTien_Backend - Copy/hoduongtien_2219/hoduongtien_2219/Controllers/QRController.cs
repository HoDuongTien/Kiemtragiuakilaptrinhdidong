﻿
using System;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/qr")]
    [Authorize]
    public class QRController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public QRController(ApplicationDbContext db)
        {
            _db = db;
        }

        private int? GetUserId()
        {
            var value = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            return int.TryParse(value, out int id)
                ? id
                : null;
        }

        private static string HashCode(string code)
        {
            byte[] bytes = SHA256.HashData(
                Encoding.UTF8.GetBytes(code));

            return Convert.ToHexString(bytes);
        }

        // ==========================================
        // 1. PARENT TAO MA QR
        // POST: api/qr/child/1/generate
        // ==========================================
        [HttpPost("child/{childId:int}/generate")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Generate(
            int childId)
        {
            var parentId = GetUserId();

            if (parentId == null)
                return Unauthorized();

            var child = await _db.Children
                .AsNoTracking()
                .FirstOrDefaultAsync(c =>
                    c.Id == childId &&
                    c.ParentId == parentId.Value);

            if (child == null)
            {
                return NotFound(new
                {
                    message = "Khong tim thay ho so con."
                });
            }

            if (child.ChildUserId == null)
            {
                return BadRequest(new
                {
                    message =
                        "Can tao tai khoan Child truoc khi lien ket."
                });
            }

            // Tao ma ngau nhien an toan.
            string code = Convert.ToHexString(
                RandomNumberGenerator.GetBytes(24));

            var pairing = new PairingCode
            {
                ChildId = childId,
                CodeHash = HashCode(code),
                ExpiresAt = DateTime.UtcNow.AddMinutes(5),
                IsUsed = false
            };

            _db.PairingCodes.Add(pairing);
            await _db.SaveChangesAsync();

            return Ok(new
            {
                message = "Tao ma lien ket thanh cong.",
                childId,
                code,
                expiresAt = pairing.ExpiresAt
            });
        }

        // ==========================================
        // 2. CHILD QUET QR VA LIEN KET THIET BI
        // POST: api/qr/pair
        // ==========================================
        [HttpPost("pair")]
        [Authorize(Roles = "Child")]
        public async Task<IActionResult> Pair(
            [FromBody] PairDeviceDto dto)
        {
            var userId = GetUserId();

            if (userId == null)
                return Unauthorized();

            var code = dto.Code.Trim();
            var deviceName = dto.DeviceName.Trim();

            if (string.IsNullOrWhiteSpace(code) ||
                string.IsNullOrWhiteSpace(deviceName))
            {
                return BadRequest(new
                {
                    message = "Ma QR hoac ten thiet bi khong hop le."
                });
            }

            var codeHash = HashCode(code);

            await using var transaction =
                await _db.Database.BeginTransactionAsync();

            var pairing = await _db.PairingCodes
                .AsNoTracking()
                .Where(p =>
                    p.CodeHash == codeHash &&
                    !p.IsUsed &&
                    p.ExpiresAt > DateTime.UtcNow &&
                    p.Child.ChildUserId == userId.Value)
                .Select(p => new
                {
                    p.Id,
                    p.ChildId
                })
                .FirstOrDefaultAsync();

            if (pairing == null)
            {
                return BadRequest(new
                {
                    message =
                        "Ma QR khong hop le, het han hoac khong thuoc tai khoan nay."
                });
            }

            // Danh dau da su dung theo dieu kien.
            // Ngan hai request su dung cung mot ma.
            int updated = await _db.PairingCodes
                .Where(p =>
                    p.Id == pairing.Id &&
                    !p.IsUsed &&
                    p.ExpiresAt > DateTime.UtcNow)
                .ExecuteUpdateAsync(setters =>
                    setters.SetProperty(
                        p => p.IsUsed, true));

            if (updated != 1)
            {
                return Conflict(new
                {
                    message = "Ma QR da duoc su dung."
                });
            }

            var device = new Device
            {
                ChildId = pairing.ChildId,
                DeviceName = deviceName,
                DeviceModel = dto.DeviceModel,
                CreatedAt = DateTime.UtcNow
            };

            _db.Devices.Add(device);

            await _db.SaveChangesAsync();
            await transaction.CommitAsync();

            return Ok(new
            {
                message = "Lien ket thiet bi thanh cong.",
                device.Id,
                device.ChildId,
                device.DeviceName,
                device.DeviceModel,
                device.CreatedAt
            });
        }
    }
}
