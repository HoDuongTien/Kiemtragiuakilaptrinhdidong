﻿
using System;
using System.Linq;
using System.Threading.Tasks;
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/admin")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public AdminController(ApplicationDbContext db)
        {
            _db = db;
        }

        // ==========================================
        // 1. THONG KE DASHBOARD ADMIN
        // GET: api/admin/dashboard
        // ==========================================
        [HttpGet("dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            return Ok(new
            {
                totalUsers = await _db.Users.CountAsync(),

                totalAdmins = await _db.Users
                    .CountAsync(u => u.Role == "Admin"),

                totalParents = await _db.Users
                    .CountAsync(u => u.Role == "Parent"),

                totalChildAccounts = await _db.Users
                    .CountAsync(u => u.Role == "Child"),

                totalChildProfiles = await _db.Children
                    .CountAsync(),

                totalDevices = await _db.Devices
                    .CountAsync()
            });
        }

        // ==========================================
        // 2. LAY DANH SACH TAI KHOAN
        // GET: api/admin/users
        // ==========================================
        [HttpGet("users")]
        public async Task<IActionResult> GetUsers(
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20)
        {
            page = Math.Max(1, page);
            pageSize = Math.Clamp(pageSize, 1, 100);

            var totalUsers = await _db.Users.CountAsync();

            var users = await _db.Users
                .AsNoTracking()
                .OrderBy(u => u.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(u => new
                {
                    u.Id,
                    u.FullName,
                    u.Email,
                    u.Role,
                    u.CreatedAt
                })
                .ToListAsync();

            return Ok(new
            {
                page,
                pageSize,
                totalUsers,
                totalPages = (int)Math.Ceiling(
                    (double)totalUsers / pageSize),
                users
            });
        }

        // ==========================================
        // 3. XEM CHI TIET TAI KHOAN
        // GET: api/admin/users/1
        // ==========================================
        [HttpGet("users/{id:int}")]
        public async Task<IActionResult> GetUser(int id)
        {
            var user = await _db.Users
                .AsNoTracking()
                .Where(u => u.Id == id)
                .Select(u => new
                {
                    u.Id,
                    u.FullName,
                    u.Email,
                    u.Role,
                    u.CreatedAt
                })
                .FirstOrDefaultAsync();

            if (user == null)
            {
                return NotFound(new
                {
                    message = "Khong tim thay tai khoan."
                });
            }

            return Ok(user);
        }

        // ==========================================
        // 4. CAP NHAT VAI TRO NGUOI DUNG
        // PUT: api/admin/users/1/role
        // ==========================================
        [HttpPut("users/{id:int}/role")]
        public async Task<IActionResult> UpdateUserRole(
            int id,
            [FromBody] UpdateUserRoleDto dto)
        {
            var user = await _db.Users
                .FirstOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "Khong tim thay tai khoan."
                });
            }

            if (user.Role == dto.Role)
            {
                return Ok(new
                {
                    message = "Vai tro khong thay doi.",
                    user.Id,
                    user.Role
                });
            }

            // Khong cho phep cap quyen Admin
            // hoac thay doi vai tro Admin.
            if (user.Role == "Admin" || dto.Role == "Admin")
            {
                return BadRequest(new
                {
                    message = "Khong ho tro thay doi vai tro Admin."
                });
            }

            // Khong thay doi vai tro neu tai khoan
            // dang lien ket voi ho so tre.
            var hasChildRelationship = await _db.Children
                .AnyAsync(c =>
                    c.ParentId == id ||
                    c.ChildUserId == id);

            if (hasChildRelationship)
            {
                return BadRequest(new
                {
                    message = "Tai khoan dang lien ket ho so tre."
                });
            }

            // Khong cho doi truc tiep sang Child.
            // Tai khoan Child phai duoc tao
            // qua quy trinh lien ket ho so tre.
            if (dto.Role == "Child")
            {
                return BadRequest(new
                {
                    message = "Hay tao tai khoan Child qua ho so tre."
                });
            }

            // Chi cho phep doi tai khoan Child
            // chua lien ket ho so ve Parent.
            if (user.Role != "Child" || dto.Role != "Parent")
            {
                return BadRequest(new
                {
                    message = "Thay doi vai tro khong duoc ho tro."
                });
            }

            user.Role = dto.Role;

            await _db.SaveChangesAsync();

            return Ok(new
            {
                message = "Cap nhat vai tro thanh cong.",
                user.Id,
                user.FullName,
                user.Email,
                user.Role
            });
        }
    }
}
