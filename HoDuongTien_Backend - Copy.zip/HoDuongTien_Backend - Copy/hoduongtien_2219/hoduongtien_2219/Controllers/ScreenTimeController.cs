﻿
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/screen-time")]
    [Authorize]
    public class ScreenTimeController : KidSafeControllerBase
    {
        public ScreenTimeController(
            ApplicationDbContext db) : base(db)
        {
        }

        // =========================================
        // 1. XEM GIOI HAN THOI GIAN CUA TRE
        // GET: api/screen-time/child/1
        // =========================================
        [HttpGet("child/{childId:int}")]
        public async Task<IActionResult> Get(int childId)
        {
            if (!await CanReadChild(childId))
                return Forbid();

            var rule = await Db.ScreenTimeRules
                .AsNoTracking()
                .Where(s => s.ChildId == childId)
                .Select(s => new
                {
                    s.Id,
                    s.ChildId,
                    s.DailyLimitMinutes,
                    s.IsEnabled
                })
                .FirstOrDefaultAsync();

            if (rule == null)
            {
                return Ok(new
                {
                    ChildId = childId,
                    DailyLimitMinutes = 120,
                    IsEnabled = false,
                    IsConfigured = false
                });
            }

            return Ok(rule);
        }

        // =========================================
        // 2. PARENT DAT / CAP NHAT GIOI HAN
        // PUT: api/screen-time/child/1
        // =========================================
        [HttpPut("child/{childId:int}")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Set(
            int childId,
            [FromBody] ScreenTimeDto dto)
        {
            if (!await OwnsChild(childId))
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre."
                });

            var rule = await Db.ScreenTimeRules
                .FirstOrDefaultAsync(s =>
                    s.ChildId == childId);

            if (rule == null)
            {
                rule = new ScreenTimeRule
                {
                    ChildId = childId
                };

                Db.ScreenTimeRules.Add(rule);
            }

            rule.DailyLimitMinutes = dto.DailyLimitMinutes;
            rule.IsEnabled = dto.IsEnabled;

            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Luu gioi han thanh cong.",
                rule.Id,
                rule.ChildId,
                rule.DailyLimitMinutes,
                rule.IsEnabled
            });
        }
    }
}
