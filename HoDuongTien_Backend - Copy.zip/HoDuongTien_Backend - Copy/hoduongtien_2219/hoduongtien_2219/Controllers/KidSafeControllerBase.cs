﻿
using System.Security.Claims;
using hoduongtien_2219.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    public abstract class KidSafeControllerBase : ControllerBase
    {
        protected readonly ApplicationDbContext Db;

        protected KidSafeControllerBase(ApplicationDbContext db)
        {
            Db = db;
        }

        protected int? CurrentUserId
        {
            get
            {
                var value = User.FindFirstValue(
                    ClaimTypes.NameIdentifier);

                return int.TryParse(value, out int id)
                    ? id
                    : null;
            }
        }

        protected Task<bool> OwnsChild(int childId)
        {
            return Db.Children.AnyAsync(c =>
                c.Id == childId &&
                c.ParentId == CurrentUserId);
        }

        protected Task<bool> IsMyChildAccount(int childId)
        {
            return Db.Children.AnyAsync(c =>
                c.Id == childId &&
                c.ChildUserId == CurrentUserId);
        }

        protected async Task<bool> CanReadChild(int childId)
        {
            if (User.IsInRole("Admin"))
                return true;

            if (User.IsInRole("Parent"))
                return await OwnsChild(childId);

            if (User.IsInRole("Child"))
                return await IsMyChildAccount(childId);

            return false;
        }
    }
}
