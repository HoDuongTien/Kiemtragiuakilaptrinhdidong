﻿
using System.Security.Claims;
using hoduongtien_2219.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/dashboard")]
    [Authorize]
    public class RoleDashboardController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public RoleDashboardController(ApplicationDbContext db)
        {
            _db = db;
        }

        private int? GetUserId()
        {
            var value = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            return int.TryParse(value, out int id)
                ? id
                : null;
        }

        [HttpGet("me")]
        public async Task<IActionResult> Me()
        {
            var id = GetUserId();

            if (id == null)
                return Unauthorized();

            var user = await _db.Users
                .AsNoTracking()
                .Where(u => u.Id == id.Value)
                .Select(u => new
                {
                    u.Id,
                    u.FullName,
                    u.Email,
                    u.Role
                })
                .FirstOrDefaultAsync();

            if (user == null)
                return Unauthorized();

            return Ok(user);
        }

        [HttpGet("parent")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> ParentDashboard()
        {
            var parentId = GetUserId();

            if (parentId == null)
                return Unauthorized();

            var children = await _db.Children
                .AsNoTracking()
                .Where(c => c.ParentId == parentId.Value)
                .Select(c => new
                {
                    c.Id,
                    c.FullName,
                    c.DateOfBirth,
                    c.Gender,
                    hasAccount = c.ChildUserId != null
                })
                .ToListAsync();

            return Ok(new
            {
                role = "Parent",
                totalChildren = children.Count,
                children
            });
        }

        [HttpGet("child")]
        [Authorize(Roles = "Child")]
        public async Task<IActionResult> ChildDashboard()
        {
            var userId = GetUserId();

            if (userId == null)
                return Unauthorized();

            var child = await _db.Children
                .AsNoTracking()
                .Where(c => c.ChildUserId == userId.Value)
                .Select(c => new
                {
                    c.Id,
                    c.FullName,
                    c.DateOfBirth,
                    c.Gender,
                    c.ParentId
                })
                .FirstOrDefaultAsync();

            if (child == null)
                return NotFound(new
                {
                    message = "Tai khoan chua lien ket ho so tre."
                });

            return Ok(new
            {
                role = "Child",
                child
            });
        }
    }
}
