﻿using Microsoft.AspNetCore.Mvc;

namespace hoduongtien_2219.Controllers
{
    public class ChildrenController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
