﻿
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/devices")]
    [Authorize]
    public class DevicesController : KidSafeControllerBase
    {
        public DevicesController(ApplicationDbContext db)
            : base(db)
        {
        }

        // Lay danh sach thiet bi cua tre
        [HttpGet("child/{childId:int}")]
        public async Task<IActionResult> GetAll(int childId)
        {
            if (!await CanReadChild(childId))
                return Forbid();

            var devices = await Db.Devices
                .AsNoTracking()
                .Where(d => d.ChildId == childId)
                .Select(d => new
                {
                    d.Id,
                    d.ChildId,
                    d.DeviceName,
                    d.DeviceModel,
                    d.CreatedAt
                })
                .ToListAsync();

            return Ok(devices);
        }

        // Phu huynh them thiet bi
        [HttpPost("child/{childId:int}")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Create(
            int childId,
            [FromBody] DeviceDto dto)
        {
            if (!await OwnsChild(childId))
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre."
                });

            var device = new Device
            {
                ChildId = childId,
                DeviceName = dto.DeviceName.Trim(),
                DeviceModel = dto.DeviceModel
            };

            Db.Devices.Add(device);
            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Them thiet bi thanh cong.",
                device.Id,
                device.ChildId,
                device.DeviceName,
                device.DeviceModel
            });
        }

        // Phu huynh cap nhat thiet bi
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Update(
            int id,
            [FromBody] DeviceDto dto)
        {
            var device = await Db.Devices
                .FirstOrDefaultAsync(d =>
                    d.Id == id &&
                    d.Child.ParentId == CurrentUserId);

            if (device == null)
                return NotFound();

            device.DeviceName = dto.DeviceName.Trim();
            device.DeviceModel = dto.DeviceModel;

            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Cap nhat thiet bi thanh cong.",
                device.Id,
                device.DeviceName,
                device.DeviceModel
            });
        }

        // Phu huynh xoa thiet bi
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Delete(int id)
        {
            var device = await Db.Devices
                .FirstOrDefaultAsync(d =>
                    d.Id == id &&
                    d.Child.ParentId == CurrentUserId);

            if (device == null)
                return NotFound();

            Db.Devices.Remove(device);
            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Xoa thiet bi thanh cong."
            });
        }
    }
}
