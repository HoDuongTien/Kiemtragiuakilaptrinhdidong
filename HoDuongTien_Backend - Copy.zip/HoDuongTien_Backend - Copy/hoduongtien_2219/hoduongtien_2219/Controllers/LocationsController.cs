﻿using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/locations")]
    [Authorize]
    public class LocationsController : ControllerBase
    {
        private readonly ApplicationDbContext _db;

        public LocationsController(ApplicationDbContext db)
        {
            _db = db;
        }

        private int? GetCurrentUserId()
        {
            var value = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            return int.TryParse(value, out int id)
                ? id
                : null;
        }

        // ==========================================
        // 1. CHILD GUI VI TRI GPS
        // POST: api/locations/child/1
        // ==========================================
        [HttpPost("child/{childId:int}")]
        [Authorize(Roles = "Child")]
        public async Task<IActionResult> UploadLocation(
            int childId,
            [FromBody] LocationDto dto)
        {
            var userId = GetCurrentUserId();

            if (userId == null)
                return Unauthorized();

            var isMyAccount = await _db.Children
                .AnyAsync(c =>
                    c.Id == childId &&
                    c.ChildUserId == userId.Value);

            if (!isMyAccount)
            {
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre hop le."
                });
            }

            var location = new ChildLocation
            {
                ChildId = childId,
                Latitude = dto.Latitude,
                Longitude = dto.Longitude,
                RecordedAt = DateTime.UtcNow
            };

            _db.Locations.Add(location);

            await _db.SaveChangesAsync();

            return Ok(new
            {
                message = "Cap nhat vi tri thanh cong.",
                location.Id,
                location.ChildId,
                location.Latitude,
                location.Longitude,
                location.RecordedAt
            });
        }

        // ==========================================
        // 2. PARENT XEM VI TRI MOI NHAT
        // GET: api/locations/child/1/latest
        // ==========================================
        [HttpGet("child/{childId:int}/latest")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> GetLatestLocation(
            int childId)
        {
            var parentId = GetCurrentUserId();

            if (parentId == null)
                return Unauthorized();

            var ownsChild = await _db.Children
                .AnyAsync(c =>
                    c.Id == childId &&
                    c.ParentId == parentId.Value);

            if (!ownsChild)
            {
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre."
                });
            }

            var location = await _db.Locations
                .AsNoTracking()
                .Where(l => l.ChildId == childId)
                .OrderByDescending(l => l.RecordedAt)
                .ThenByDescending(l => l.Id)
                .Select(l => new
                {
                    l.Id,
                    l.ChildId,
                    l.Latitude,
                    l.Longitude,
                    l.RecordedAt
                })
                .FirstOrDefaultAsync();

            if (location == null)
            {
                return NotFound(new
                {
                    message = "Tre chua gui vi tri GPS."
                });
            }

            return Ok(location);
        }

        // ==========================================
        // 3. PARENT XEM LICH SU VI TRI
        // GET: api/locations/child/1/history
        // ==========================================
        [HttpGet("child/{childId:int}/history")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> GetLocationHistory(
            int childId,
            [FromQuery] int take = 50)
        {
            var parentId = GetCurrentUserId();

            if (parentId == null)
                return Unauthorized();

            var ownsChild = await _db.Children
                .AnyAsync(c =>
                    c.Id == childId &&
                    c.ParentId == parentId.Value);

            if (!ownsChild)
            {
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre."
                });
            }

            take = Math.Clamp(take, 1, 200);

            var locations = await _db.Locations
                .AsNoTracking()
                .Where(l => l.ChildId == childId)
                .OrderByDescending(l => l.RecordedAt)
                .ThenByDescending(l => l.Id)
                .Take(take)
                .Select(l => new
                {
                    l.Id,
                    l.ChildId,
                    l.Latitude,
                    l.Longitude,
                    l.RecordedAt
                })
                .ToListAsync();

            return Ok(new
            {
                childId,
                totalReturned = locations.Count,
                locations
            });
        }
    }
}
