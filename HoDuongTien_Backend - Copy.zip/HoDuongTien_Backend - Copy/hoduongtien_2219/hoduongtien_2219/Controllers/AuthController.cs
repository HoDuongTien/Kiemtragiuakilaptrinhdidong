﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

using hoduongtien_2219.DTOs;
using hoduongtien_2219.Services;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [EnableRateLimiting("auth")]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthController(AuthService authService)
        {
            _authService = authService;
        }

        // ==========================================
        // 1. DANG KY TAI KHOAN
        // POST: api/auth/register
        // ==========================================
        [HttpPost("register")]
        public async Task<IActionResult> Register(
            [FromBody] RegisterDto dto)
        {
            var result = await _authService.RegisterAsync(dto);

            if (!result.Success)
            {
                return BadRequest(new
                {
                    message = result.Message
                });
            }

            return Ok(new
            {
                message = result.Message
            });
        }

        // ==========================================
        // 2. DANG NHAP BANG EMAIL + MAT KHAU
        // POST: api/auth/login
        // ==========================================
        [HttpPost("login")]
        public async Task<IActionResult> Login(
            [FromBody] LoginDto dto)
        {
            var result = await _authService.LoginAsync(dto);

            if (!result.Success)
            {
                return BadRequest(new
                {
                    message = result.Message
                });
            }

            return Ok(new
            {
                message = result.Message
            });
        }

        // ==========================================
        // 3. XAC THUC EMAIL OTP
        // POST: api/auth/verify-otp
        // ==========================================
        [HttpPost("verify-otp")]
        public async Task<IActionResult> VerifyOtp(
            [FromBody] VerifyOtpDto dto)
        {
            var result = await _authService.VerifyOtpAsync(dto);

            if (!result.Success)
            {
                return BadRequest(new
                {
                    message = result.Message
                });
            }

            return Ok(new
            {
                message = result.Message,
                data = result.Data
            });
        }
    }
}
