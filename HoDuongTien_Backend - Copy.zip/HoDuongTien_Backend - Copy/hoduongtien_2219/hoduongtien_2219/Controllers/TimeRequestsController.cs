﻿
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/time-requests")]
    [Authorize]
    public class TimeRequestsController : KidSafeControllerBase
    {
        public TimeRequestsController(
            ApplicationDbContext db) : base(db)
        {
        }

        // =========================================
        // 1. CHILD GUI YEU CAU THEM THOI GIAN
        // POST: api/time-requests/child/1
        // =========================================
        [HttpPost("child/{childId:int}")]
        [Authorize(Roles = "Child")]
        public async Task<IActionResult> Request(
            int childId,
            [FromBody] TimeRequestDto dto)
        {
            if (!await IsMyChildAccount(childId))
            {
                return Forbid();
            }

            bool hasPending = await Db.TimeRequests
                .AnyAsync(r =>
                    r.ChildId == childId &&
                    r.Status == "Pending");

            if (hasPending)
            {
                return Conflict(new
                {
                    message =
                        "Da co yeu cau dang cho xu ly."
                });
            }

            var request = new TimeRequest
            {
                ChildId = childId,
                RequestedMinutes = dto.RequestedMinutes,
                Reason = dto.Reason.Trim(),
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            Db.TimeRequests.Add(request);
            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Gui yeu cau thanh cong.",
                request.Id,
                request.ChildId,
                request.RequestedMinutes,
                request.Reason,
                request.Status,
                request.CreatedAt
            });
        }

        // =========================================
        // 2. XEM DANH SACH YEU CAU CUA TRE
        // GET: api/time-requests/child/1
        // =========================================
        [HttpGet("child/{childId:int}")]
        public async Task<IActionResult> GetRequests(
            int childId)
        {
            if (!await CanReadChild(childId))
            {
                return Forbid();
            }

            var requests = await Db.TimeRequests
                .AsNoTracking()
                .Where(r => r.ChildId == childId)
                .OrderByDescending(r => r.CreatedAt)
                .Select(r => new
                {
                    r.Id,
                    r.ChildId,
                    r.RequestedMinutes,
                    r.Reason,
                    r.Status,
                    r.CreatedAt
                })
                .ToListAsync();

            return Ok(requests);
        }

        // =========================================
        // 3. PARENT DUYET / TU CHOI YEU CAU
        // PUT: api/time-requests/1/review
        // =========================================
        [HttpPut("{id:int}/review")]
        [Authorize(Roles = "Parent")]
        public async Task<IActionResult> Review(
            int id,
            [FromBody] ReviewTimeRequestDto dto)
        {
            if (dto.Decision != "Approved" &&
                dto.Decision != "Rejected")
            {
                return BadRequest(new
                {
                    message =
                        "Decision phai la Approved hoac Rejected."
                });
            }

            var request = await Db.TimeRequests
                .FirstOrDefaultAsync(r =>
                    r.Id == id &&
                    r.Child.ParentId == CurrentUserId);

            if (request == null)
            {
                return NotFound(new
                {
                    message =
                        "Khong tim thay yeu cau hoac khong co quyen."
                });
            }

            if (request.Status != "Pending")
            {
                return Conflict(new
                {
                    message =
                        "Yeu cau nay da duoc xu ly."
                });
            }

            request.Status = dto.Decision;

            await Db.SaveChangesAsync();

            return Ok(new
            {
                message = "Xu ly yeu cau thanh cong.",
                request.Id,
                request.ChildId,
                request.RequestedMinutes,
                request.Status
            });
        }
    }
}
