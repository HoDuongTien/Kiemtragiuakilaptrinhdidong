
using System.Text;
using System.Threading.RateLimiting;

using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

using hoduongtien_2219.Data;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories;
using hoduongtien_2219.Repositories.Interfaces;
using hoduongtien_2219.Services;

var builder = WebApplication.CreateBuilder(args);

// ==========================================
// 1. DANG KY CONTROLLERS
// ==========================================
builder.Services.AddControllers();

// ==========================================
// 2. CAU HINH SWAGGER + JWT
// ==========================================
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition(
        "Bearer",
        new OpenApiSecurityScheme
        {
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Nhap JWT Token (khong can them Bearer)"
        }
    );

    options.AddSecurityRequirement(
        new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        }
    );
});

// ==========================================
// 3. KET NOI SQL SERVER
// ==========================================
var connectionString = builder.Configuration
    .GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException(
        "Chua cau hinh DefaultConnection"
    );

builder.Services.AddDbContext<ApplicationDbContext>(
    options =>
    {
        options.UseSqlServer(connectionString);
    }
);

// ==========================================
// 4. DANG KY REPOSITORY PATTERN
// ==========================================

// Generic Repository
builder.Services.AddScoped(
    typeof(IRepository<>),
    typeof(Repository<>)
);

// Child Repository
builder.Services.AddScoped<
    IChildRepository,
    ChildRepository
>();

// User Repository
builder.Services.AddScoped<
    IUserRepository,
    UserRepository
>();

// Email OTP Repository
builder.Services.AddScoped<
    IEmailOtpRepository,
    EmailOtpRepository
>();

// ==========================================
// 5. DANG KY SERVICES
// ==========================================

// JWT Service
builder.Services.AddScoped<JwtService>();

// Email SMTP Service
builder.Services.AddScoped<EmailService>();

// Authentication Service
builder.Services.AddScoped<AuthService>();

// Child CRUD Service
builder.Services.AddScoped<ChildService>();

// Password Hasher
builder.Services.AddScoped<
    IPasswordHasher<AppUser>,
    PasswordHasher<AppUser>
>();

// ==========================================
// 6. CAU HINH RATE LIMITING
// ==========================================
// Han che spam API dang nhap va OTP
// 5 request / 1 phut / IP
// ==========================================
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = 429;

    options.AddPolicy("auth", context =>
    {
        var ipAddress =
            context.Connection.RemoteIpAddress?
                .ToString() ?? "unknown";

        return RateLimitPartition.GetFixedWindowLimiter(
            partitionKey: ipAddress,
            factory: _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 5,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0,
                AutoReplenishment = true
            }
        );
    });
});

// ==========================================
// 7. CAU HINH JWT AUTHENTICATION
// ==========================================
var jwtKey = builder.Configuration["Jwt:Key"]
    ?? throw new InvalidOperationException(
        "Chua cau hinh Jwt:Key"
    );

var jwtIssuer = builder.Configuration["Jwt:Issuer"]
    ?? throw new InvalidOperationException(
        "Chua cau hinh Jwt:Issuer"
    );

var jwtAudience = builder.Configuration["Jwt:Audience"]
    ?? throw new InvalidOperationException(
        "Chua cau hinh Jwt:Audience"
    );

if (Encoding.UTF8.GetByteCount(jwtKey) < 32)
{
    throw new InvalidOperationException(
        "Jwt:Key phai co it nhat 32 byte"
    );
}

builder.Services
    .AddAuthentication(
        JwtBearerDefaults.AuthenticationScheme
    )
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters =
            new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = jwtIssuer,

                ValidateAudience = true,
                ValidAudience = jwtAudience,

                ValidateLifetime = true,
                RequireExpirationTime = true,

                ValidateIssuerSigningKey = true,

                IssuerSigningKey =
                    new SymmetricSecurityKey(
                        Encoding.UTF8.GetBytes(jwtKey)
                    ),

                ClockSkew = TimeSpan.Zero
            };
    });

// ==========================================
// 8. CAU HINH PHAN QUYEN
// ==========================================
builder.Services.AddAuthorization();

// ==========================================
// 9. BUILD APPLICATION
// ==========================================
var app = builder.Build();

// ==========================================
// 10. CAU HINH SWAGGER
// ==========================================
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ==========================================
// 11. HTTP PIPELINE
// ==========================================

// Chuyen huong HTTPS
app.UseHttpsRedirection();

// Xac thuc JWT
app.UseAuthentication();

// Rate Limiting
app.UseRateLimiter();

// Phan quyen Admin / Parent / Child
app.UseAuthorization();

// Anh xa API Controllers
app.MapControllers();

// ==========================================
// 12. TAO ADMIN MAC DINH
// ==========================================
await AdminSeeder.SeedAsync(
    app.Services,
    app.Configuration
);

// ==========================================
// 13. CHAY BACKEND
// ==========================================
app.Run();
