﻿
using Microsoft.EntityFrameworkCore;
using hoduongtien_2219.Models;

namespace hoduongtien_2219.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(
            DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<AppUser> Users => Set<AppUser>();
        public DbSet<Child> Children => Set<Child>();
        public DbSet<Device> Devices => Set<Device>();

        public DbSet<ScreenTimeRule> ScreenTimeRules
            => Set<ScreenTimeRule>();

        public DbSet<ChildLocation> Locations
            => Set<ChildLocation>();

        public DbSet<TimeRequest> TimeRequests
            => Set<TimeRequest>();

        public DbSet<EmailOtp> EmailOtps
            => Set<EmailOtp>();

        public DbSet<PairingCode> PairingCodes
            => Set<PairingCode>();

        protected override void OnModelCreating(
            ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Email không được trùng
            modelBuilder.Entity<AppUser>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // Quan hệ phụ huynh - trẻ em
            modelBuilder.Entity<Child>()
                .HasOne(c => c.Parent)
                .WithMany()
                .HasForeignKey(c => c.ParentId)
                .OnDelete(DeleteBehavior.Restrict);

            // Tài khoản của trẻ
            modelBuilder.Entity<Child>()
                .HasOne(c => c.ChildUser)
                .WithMany()
                .HasForeignKey(c => c.ChildUserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Child>()
                .HasIndex(c => c.ChildUserId)
                .IsUnique()
                .HasFilter("[ChildUserId] IS NOT NULL");

            // Thiết bị
            modelBuilder.Entity<Device>()
                .HasOne(d => d.Child)
                .WithMany()
                .HasForeignKey(d => d.ChildId)
                .OnDelete(DeleteBehavior.Cascade);

            // Giới hạn thời gian
            modelBuilder.Entity<ScreenTimeRule>()
                .HasOne(s => s.Child)
                .WithMany()
                .HasForeignKey(s => s.ChildId)
                .OnDelete(DeleteBehavior.Cascade);

            // Vị trí
            modelBuilder.Entity<ChildLocation>()
                .HasOne(l => l.Child)
                .WithMany()
                .HasForeignKey(l => l.ChildId)
                .OnDelete(DeleteBehavior.Cascade);

            // Yêu cầu thêm thời gian
            modelBuilder.Entity<TimeRequest>()
                .HasOne(t => t.Child)
                .WithMany()
                .HasForeignKey(t => t.ChildId)
                .OnDelete(DeleteBehavior.Cascade);

            // OTP
            modelBuilder.Entity<EmailOtp>()
                .HasOne(o => o.User)
                .WithMany()
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // Mã QR liên kết
            modelBuilder.Entity<PairingCode>()
                .HasOne(p => p.Child)
                .WithMany()
                .HasForeignKey(p => p.ChildId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
