﻿
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Data
{
    public static class AdminSeeder
    {
        public static async Task SeedAsync(
            IServiceProvider services,
            IConfiguration configuration)
        {
            var email = configuration["AdminSeed:Email"]?
                .Trim().ToLowerInvariant();

            var password = configuration["AdminSeed:Password"];

            if (string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(password))
            {
                return;
            }

            if (password.Length < 12)
                throw new InvalidOperationException(
                    "Mat khau Admin phai co it nhat 12 ky tu.");

            using var scope = services.CreateScope();

            var db = scope.ServiceProvider
                .GetRequiredService<ApplicationDbContext>();

            var hasher = scope.ServiceProvider
                .GetRequiredService<IPasswordHasher<AppUser>>();

            var existingUser = await db.Users
                .AnyAsync(u => u.Email == email);

            if (existingUser)
            {
                // Khong tu dong nang quyen tai khoan da ton tai.
                return;
            }

            var admin = new AppUser
            {
                FullName = "System Administrator",
                Email = email,
                Role = "Admin",
                CreatedAt = DateTime.UtcNow
            };

            admin.PasswordHash =
                hasher.HashPassword(admin, password);

            db.Users.Add(admin);

            await db.SaveChangesAsync();
        }
    }
}
