﻿
using Microsoft.EntityFrameworkCore;
using hoduongtien_2219.Data;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories.Interfaces;

namespace hoduongtien_2219.Repositories
{
    public class EmailOtpRepository
        : Repository<EmailOtp>, IEmailOtpRepository
    {
        public EmailOtpRepository(ApplicationDbContext context)
            : base(context)
        {
        }

        public async Task<EmailOtp?> GetLatestValidOtpAsync(int userId)
        {
            return await _context.EmailOtps
                .Where(o =>
                    o.UserId == userId &&
                    !o.IsUsed &&
                    o.ExpiresAt > DateTime.UtcNow)
                .OrderByDescending(o => o.Id)
                .FirstOrDefaultAsync();
        }
    }
}
