﻿
using hoduongtien_2219.Models;

namespace hoduongtien_2219.Repositories.Interfaces
{
    public interface IUserRepository : IRepository<AppUser>
    {
        Task<AppUser?> GetByEmailAsync(string email);
    }
}
