﻿
using hoduongtien_2219.Models;

namespace hoduongtien_2219.Repositories.Interfaces
{
    public interface IChildRepository : IRepository<Child>
    {
        Task<IEnumerable<Child>> GetByParentIdAsync(
            int parentId);

        Task<Child?> GetChildWithDetailsAsync(int id);
    }
}
