﻿
using hoduongtien_2219.Models;

namespace hoduongtien_2219.Repositories.Interfaces
{
    public interface IEmailOtpRepository : IRepository<EmailOtp>
    {
        Task<EmailOtp?> GetLatestValidOtpAsync(int userId);
    }
}
