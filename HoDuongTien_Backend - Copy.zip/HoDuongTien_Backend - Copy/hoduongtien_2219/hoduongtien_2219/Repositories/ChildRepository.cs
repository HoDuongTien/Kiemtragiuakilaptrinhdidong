﻿
using Microsoft.EntityFrameworkCore;
using hoduongtien_2219.Data;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories.Interfaces;

namespace hoduongtien_2219.Repositories
{
    public class ChildRepository :
        Repository<Child>, IChildRepository
    {
        public ChildRepository(ApplicationDbContext context)
            : base(context)
        {
        }

        public async Task<IEnumerable<Child>> GetByParentIdAsync(
            int parentId)
        {
            return await _context.Children
                .AsNoTracking()
                .Where(c => c.ParentId == parentId)
                .ToListAsync();
        }

        public async Task<Child?> GetChildWithDetailsAsync(int id)
        {
            return await _context.Children
                .AsNoTracking()
                .Include(c => c.Parent)
                .Include(c => c.ChildUser)
                .FirstOrDefaultAsync(c => c.Id == id);
        }
    }
}
