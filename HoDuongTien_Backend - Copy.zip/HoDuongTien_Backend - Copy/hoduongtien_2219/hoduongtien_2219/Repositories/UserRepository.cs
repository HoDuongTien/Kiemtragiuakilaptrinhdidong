﻿
using Microsoft.EntityFrameworkCore;
using hoduongtien_2219.Data;
using hoduongtien_2219.Models;
using hoduongtien_2219.Repositories.Interfaces;

namespace hoduongtien_2219.Repositories
{
    public class UserRepository : Repository<AppUser>, IUserRepository
    {
        public UserRepository(ApplicationDbContext context)
            : base(context)
        {
        }

        public async Task<AppUser?> GetByEmailAsync(string email)
        {
            return await _context.Users
                .FirstOrDefaultAsync(u => u.Email == email);
        }
    }
}
