﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class ScreenTimeDto
    {
        [Range(1, 1440)]
        public int DailyLimitMinutes { get; set; } = 120;

        public bool IsEnabled { get; set; } = true;
    }

    public class TimeRequestDto
    {
        [Range(1, 1440)]
        public int RequestedMinutes { get; set; }

        [Required]
        [StringLength(500, MinimumLength = 2)]
        public string Reason { get; set; } = "";
    }

    public class ReviewTimeRequestDto
    {
        [Required]
        public string Decision { get; set; } = "";
    }
}
