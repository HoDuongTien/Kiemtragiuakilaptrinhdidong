﻿
using System.Security.Claims;
using hoduongtien_2219.Data;
using hoduongtien_2219.DTOs;
using hoduongtien_2219.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace hoduongtien_2219.Controllers
{
    [ApiController]
    [Route("api/Child/{childId:int}/account")]
    [Authorize(Roles = "Parent")]
    public class ChildAccountController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IPasswordHasher<AppUser> _hasher;

        public ChildAccountController(
            ApplicationDbContext context,
            IPasswordHasher<AppUser> hasher)
        {
            _context = context;
            _hasher = hasher;
        }

        [HttpPost]
        public async Task<IActionResult> CreateAccount(
            int childId,
            [FromBody] CreateChildAccountDto dto)
        {
            var claim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(claim, out int parentId))
                return Unauthorized();

            var child = await _context.Children
                .FirstOrDefaultAsync(c =>
                    c.Id == childId &&
                    c.ParentId == parentId);

            if (child == null)
                return NotFound(new
                {
                    message = "Khong tim thay ho so tre."
                });

            if (child.ChildUserId != null)
                return Conflict(new
                {
                    message = "Tre da co tai khoan."
                });

            var email = dto.Email.Trim().ToLowerInvariant();

            var emailExists = await _context.Users
                .AnyAsync(u => u.Email == email);

            if (emailExists)
                return Conflict(new
                {
                    message = "Email da duoc su dung."
                });

            var user = new AppUser
            {
                FullName = child.FullName,
                Email = email,
                Role = "Child",
                CreatedAt = DateTime.UtcNow
            };

            user.PasswordHash =
                _hasher.HashPassword(user, dto.Password);

            await using var transaction =
                await _context.Database.BeginTransactionAsync();

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            child.ChildUserId = user.Id;
            await _context.SaveChangesAsync();

            await transaction.CommitAsync();

            return Ok(new
            {
                message = "Tao tai khoan Child thanh cong.",
                userId = user.Id,
                childId = child.Id,
                email = user.Email,
                role = user.Role
            });
        }
    }
}
