﻿using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class LocationDto
    {
        [Range(-90, 90)]
        public double Latitude { get; set; }

        [Range(-180, 180)]
        public double Longitude { get; set; }
    }
}
