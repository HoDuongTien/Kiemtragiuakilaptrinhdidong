﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class VerifyOtpDto
    {
        [Required, EmailAddress]
        public string Email { get; set; } = "";

        [Required]
        public string OtpCode { get; set; } = "";
    }
}
