﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class CreateChildAccountDto
    {
        [Required, EmailAddress, MaxLength(255)]
        public string Email { get; set; } = "";

        [Required, MinLength(8)]
        public string Password { get; set; } = "";
    }
}
