﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class UpdateUserRoleDto
    {
        [Required]
        [RegularExpression("^(Admin|Parent|Child)$",
            ErrorMessage = "Role khong hop le.")]
        public string Role { get; set; } = "";
    }
}
