﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class PairDeviceDto
    {
        [Required]
        public string Code { get; set; } = "";

        [Required]
        [MaxLength(100)]
        public string DeviceName { get; set; } = "";

        [MaxLength(200)]
        public string? DeviceModel { get; set; }
    }
}
