﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class DeviceDto
    {
        [Required(ErrorMessage = "Vui long nhap ten thiet bi.")]
        [MaxLength(100)]
        public string DeviceName { get; set; } = "";

        [MaxLength(200)]
        public string? DeviceModel { get; set; }
    }
}
