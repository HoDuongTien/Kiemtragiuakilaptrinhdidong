﻿
using System.ComponentModel.DataAnnotations;

namespace hoduongtien_2219.DTOs
{
    public class UpdateChildDto
    {
        [Required]
        [StringLength(100)]
        public string FullName { get; set; } = string.Empty;

        public DateTime? DateOfBirth { get; set; }

        [StringLength(20)]
        public string? Gender { get; set; }
    }
}
