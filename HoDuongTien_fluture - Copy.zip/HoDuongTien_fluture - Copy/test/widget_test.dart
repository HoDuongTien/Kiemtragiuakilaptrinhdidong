
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:hoduongtien_fluture/main.dart';

void main() {
  testWidgets(
    'KidSafe hien thi man hinh dang nhap',
        (WidgetTester tester) async {
      // Khoi tao ung dung KidSafe
      await tester.pumpWidget(const KidSafeApp());

      // Kiem tra tieu de man hinh
      expect(
        find.text('KidSafe - Đăng nhập'),
        findsOneWidget,
      );

      // Kiem tra nut dang nhap
      expect(
        find.text('Đăng nhập'),
        findsOneWidget,
      );

      // Kiem tra hai o nhap Email va Mat khau
      expect(
        find.byType(TextField),
        findsNWidgets(2),
      );

      // Kiem tra nut chuyen sang dang ky
      expect(
        find.text('Chưa có tài khoản? Đăng ký'),
        findsOneWidget,
      );
    },
  );
}
