package com.example.hoduongtien_fluture

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
