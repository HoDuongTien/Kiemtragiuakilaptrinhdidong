class ApiConfig {
  static const String baseUrl =
      'http://hoduongtien2219.somee.com/api';
}