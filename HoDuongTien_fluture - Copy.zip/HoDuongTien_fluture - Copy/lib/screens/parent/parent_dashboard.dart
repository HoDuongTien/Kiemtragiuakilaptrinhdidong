
import 'package:flutter/material.dart';

import 'children_screen.dart';
import 'location_screen.dart';
import 'pairing_screen.dart';
import 'screen_time_screen.dart';
import 'time_requests_screen.dart';

class ParentDashboard extends StatelessWidget {
  final String token;

  const ParentDashboard({
    super.key,
    required this.token,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KidSafe - Phụ huynh'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 20),

          const Icon(
            Icons.family_restroom,
            size: 85,
            color: Colors.blue,
          ),

          const SizedBox(height: 16),

          const Center(
            child: Text(
              'Xin chào phụ huynh!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(height: 8),

          const Center(
            child: Text(
              'Quản lý và bảo vệ trẻ cùng KidSafe',
              style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
              ),
            ),
          ),

          const SizedBox(height: 30),

          // 1. QUẢN LÝ TRẺ EM
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.child_care,
                color: Colors.blue,
              ),
              title: const Text(
                'Quản lý trẻ em',
              ),
              subtitle: const Text(
                'Thêm, sửa, xóa hồ sơ trẻ',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChildrenScreen(
                      token: token,
                    ),
                  ),
                );
              },
            ),
          ),

          // 2. XEM VỊ TRÍ GPS
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.location_on,
                color: Colors.red,
              ),
              title: const Text(
                'Xem vị trí của trẻ',
              ),
              subtitle: const Text(
                'Xem vị trí mới nhất và lịch sử GPS',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LocationScreen(
                      token: token,
                    ),
                  ),
                );
              },
            ),
          ),

          // 3. GHÉP NỐI THIẾT BỊ BẰNG QR
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.qr_code,
                color: Colors.purple,
              ),
              title: const Text(
                'Ghép nối thiết bị',
              ),
              subtitle: const Text(
                'Tạo mã QR để liên kết thiết bị của trẻ',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PairingScreen(
                      token: token,
                    ),
                  ),
                );
              },
            ),
          ),

          // 4. QUẢN LÝ THỜI GIAN SỬ DỤNG
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.timer,
                color: Colors.orange,
              ),
              title: const Text(
                'Quản lý thời gian sử dụng',
              ),
              subtitle: const Text(
                'Thiết lập giới hạn thời gian cho trẻ',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ScreenTimeScreen(
                      token: token,
                    ),
                  ),
                );
              },
            ),
          ),

          // 5. DUYỆT YÊU CẦU THÊM THỜI GIAN
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.notifications,
                color: Colors.green,
              ),
              title: const Text(
                'Yêu cầu thêm thời gian',
              ),
              subtitle: const Text(
                'Xem, duyệt hoặc từ chối yêu cầu của trẻ',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => TimeRequestsScreen(
                      token: token,
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
