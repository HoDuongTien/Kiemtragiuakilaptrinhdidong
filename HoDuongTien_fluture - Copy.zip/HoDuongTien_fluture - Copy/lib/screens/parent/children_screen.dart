
import 'package:flutter/material.dart';

import '../../models/child_model.dart';
import '../../services/child_service.dart';

class ChildrenScreen extends StatefulWidget {
  final String token;

  const ChildrenScreen({
    super.key,
    required this.token,
  });

  @override
  State<ChildrenScreen> createState() => _ChildrenScreenState();
}

class _ChildrenScreenState extends State<ChildrenScreen> {
  late final ChildService childService;

  List<ChildModel> children = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    childService = ChildService(token: widget.token);
    loadChildren();
  }

  Future<void> loadChildren() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await childService.getChildren();

      if (!mounted) return;

      setState(() {
        children = result;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> openChildForm({ChildModel? child}) async {
    final nameController = TextEditingController(
      text: child?.fullName ?? '',
    );

    DateTime? selectedDate = child?.dateOfBirth;

    String selectedGender =
    child?.gender == 'Female' ? 'Female' : 'Male';

    bool saving = false;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (dialogContext, setDialogState) {
            return AlertDialog(
              title: Text(
                child == null
                    ? 'Thêm trẻ em'
                    : 'Sửa thông tin trẻ',
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Họ và tên',
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 16),

                    DropdownButtonFormField<String>(
                      initialValue: selectedGender,
                      decoration: const InputDecoration(
                        labelText: 'Giới tính',
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'Male',
                          child: Text('Nam'),
                        ),
                        DropdownMenuItem(
                          value: 'Female',
                          child: Text('Nữ'),
                        ),
                      ],
                      onChanged: saving
                          ? null
                          : (value) {
                        if (value == null) return;

                        setDialogState(() {
                          selectedGender = value;
                        });
                      },
                    ),

                    const SizedBox(height: 16),

                    OutlinedButton.icon(
                      onPressed: saving
                          ? null
                          : () async {
                        final date = await showDatePicker(
                          context: dialogContext,
                          initialDate:
                          selectedDate ?? DateTime(2015),
                          firstDate: DateTime(2000),
                          lastDate: DateTime.now(),
                        );

                        if (!dialogContext.mounted) return;

                        if (date != null) {
                          setDialogState(() {
                            selectedDate = date;
                          });
                        }
                      },
                      icon: const Icon(Icons.calendar_month),
                      label: Text(
                        selectedDate == null
                            ? 'Chọn ngày sinh'
                            : '${selectedDate!.day}/'
                            '${selectedDate!.month}/'
                            '${selectedDate!.year}',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: saving
                      ? null
                      : () {
                    Navigator.of(dialogContext).pop(false);
                  },
                  child: const Text('Hủy'),
                ),

                ElevatedButton(
                  onPressed: saving
                      ? null
                      : () async {
                    final name =
                    nameController.text.trim();

                    if (name.isEmpty) {
                      ScaffoldMessenger.of(
                        dialogContext,
                      ).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Vui lòng nhập họ tên trẻ',
                          ),
                        ),
                      );
                      return;
                    }

                    setDialogState(() {
                      saving = true;
                    });

                    try {
                      if (child == null) {
                        await childService.addChild(
                          fullName: name,
                          dateOfBirth: selectedDate,
                          gender: selectedGender,
                        );
                      } else {
                        await childService.updateChild(
                          id: child.id,
                          fullName: name,
                          dateOfBirth: selectedDate,
                          gender: selectedGender,
                        );
                      }

                      if (!dialogContext.mounted) return;

                      Navigator.of(dialogContext).pop(true);
                    } catch (e) {
                      if (!dialogContext.mounted) return;

                      ScaffoldMessenger.of(
                        dialogContext,
                      ).showSnackBar(
                        SnackBar(
                          content: Text(
                            'Không lưu được: $e',
                          ),
                        ),
                      );

                      setDialogState(() {
                        saving = false;
                      });
                    }
                  },
                  child: saving
                      ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                      : const Text('Lưu'),
                ),
              ],
            );
          },
        );
      },
    );

    // Đợi hộp thoại hoàn tất trước khi giải phóng controller.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      nameController.dispose();
    });

    if (saved == true && mounted) {
      await loadChildren();
    }
  }

  Future<void> deleteChild(ChildModel child) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Xác nhận xóa'),
          content: Text(
            'Bạn có chắc muốn xóa ${child.fullName}?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(false);
              },
              child: const Text('Hủy'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(dialogContext).pop(true);
              },
              child: const Text('Xóa'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      await childService.deleteChild(child.id);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Đã xóa hồ sơ trẻ'),
        ),
      );

      await loadChildren();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Xóa thất bại: $e'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý trẻ em'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: loadChildren,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => openChildForm(),
        icon: const Icon(Icons.add),
        label: const Text('Thêm trẻ'),
      ),

      body: isLoading
          ? const Center(
        child: CircularProgressIndicator(),
      )
          : errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                errorMessage!,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: loadChildren,
                child: const Text('Thử lại'),
              ),
            ],
          ),
        ),
      )
          : children.isEmpty
          ? const Center(
        child: Text(
          'Chưa có trẻ em nào.\n'
              'Nhấn "Thêm trẻ" để bắt đầu.',
          textAlign: TextAlign.center,
        ),
      )
          : RefreshIndicator(
        onRefresh: loadChildren,
        child: ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: children.length,
          itemBuilder: (context, index) {
            final child = children[index];

            return Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.child_care),
                ),
                title: Text(child.fullName),
                subtitle: Text(
                  'Mã trẻ: ${child.id}',
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.blue,
                      ),
                      onPressed: () {
                        openChildForm(
                          child: child,
                        );
                      },
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.delete,
                        color: Colors.red,
                      ),
                      onPressed: () {
                        deleteChild(child);
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
