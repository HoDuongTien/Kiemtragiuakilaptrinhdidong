
import 'package:flutter/material.dart';

import '../../models/child_model.dart';
import '../../services/child_service.dart';
import '../../services/location_service.dart';

class LocationScreen extends StatefulWidget {
  final String token;

  const LocationScreen({
    super.key,
    required this.token,
  });

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  late final ChildService childService;
  late final LocationService locationService;

  List<ChildModel> children = [];
  List<ChildLocationModel> history = [];

  ChildModel? selectedChild;
  ChildLocationModel? latestLocation;

  bool isLoading = true;
  bool isLoadingLocation = false;

  String? errorMessage;
  String? locationMessage;

  @override
  void initState() {
    super.initState();

    childService = ChildService(token: widget.token);
    locationService = LocationService(token: widget.token);

    loadChildren();
  }

  Future<void> loadChildren() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await childService.getChildren();

      if (!mounted) return;

      setState(() {
        children = result;
        selectedChild = result.isEmpty ? null : result.first;
      });

      if (selectedChild != null) {
        await loadLocation();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => errorMessage = e.toString());
    } finally {
      if (mounted) {
        setState(() => isLoading = false);
      }
    }
  }

  Future<void> loadLocation() async {
    final child = selectedChild;
    if (child == null) return;

    setState(() {
      isLoadingLocation = true;
      latestLocation = null;
      history = [];
      locationMessage = null;
    });

    try {
      final latest = await locationService.getLatestLocation(
        child.id,
      );

      final records = await locationService.getLocationHistory(
        child.id,
      );

      if (!mounted || selectedChild?.id != child.id) return;

      setState(() {
        latestLocation = latest;
        history = records;
      });
    } catch (e) {
      if (!mounted || selectedChild?.id != child.id) return;

      setState(() {
        locationMessage = e.toString();
      });
    } finally {
      if (mounted && selectedChild?.id == child.id) {
        setState(() => isLoadingLocation = false);
      }
    }
  }

  String formatDate(DateTime date) {
    final local = date.toLocal();

    String two(int value) => value.toString().padLeft(2, '0');

    return '${two(local.day)}/${two(local.month)}/'
        '${local.year} '
        '${two(local.hour)}:${two(local.minute)}';
  }

  Widget buildLocationCard(ChildLocationModel location) {
    return Card(
      child: ListTile(
        leading: const Icon(
          Icons.location_on,
          color: Colors.red,
        ),
        title: Text(
          'Vĩ độ: ${location.latitude}\n'
              'Kinh độ: ${location.longitude}',
        ),
        subtitle: Text(
          'Cập nhật: ${formatDate(location.recordedAt)}',
        ),
        isThreeLine: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vị trí GPS của trẻ'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: isLoading ? null : loadChildren,
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            errorMessage!,
            textAlign: TextAlign.center,
          ),
        ),
      )
          : children.isEmpty
          ? const Center(
        child: Text(
          'Chưa có hồ sơ trẻ.\n'
              'Hãy thêm trẻ ở mục Quản lý trẻ em.',
          textAlign: TextAlign.center,
        ),
      )
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Chọn trẻ cần xem vị trí',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          DropdownButtonFormField<int>(
            key: ValueKey(selectedChild?.id),
            initialValue: selectedChild?.id,
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.child_care),
            ),
            items: children.map((child) {
              return DropdownMenuItem<int>(
                value: child.id,
                child: Text(child.fullName),
              );
            }).toList(),
            onChanged: isLoadingLocation
                ? null
                : (id) {
              if (id == null) return;

              setState(() {
                selectedChild = children.firstWhere(
                      (child) => child.id == id,
                );
              });

              loadLocation();
            },
          ),

          const SizedBox(height: 20),

          ElevatedButton.icon(
            onPressed:
            isLoadingLocation ? null : loadLocation,
            icon: const Icon(Icons.refresh),
            label: const Text('Cập nhật vị trí'),
          ),

          const SizedBox(height: 20),

          if (isLoadingLocation)
            const Center(
              child: CircularProgressIndicator(),
            )
          else if (locationMessage != null)
            Text(
              locationMessage!,
              textAlign: TextAlign.center,
            )
          else ...[
              const Text(
                'Vị trí mới nhất',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              if (latestLocation != null)
                buildLocationCard(latestLocation!),

              const SizedBox(height: 24),

              Text(
                'Lịch sử vị trí (${history.length})',
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              if (history.isEmpty)
                const Text('Chưa có lịch sử vị trí.'),

              ...history.map(buildLocationCard),
            ],
        ],
      ),
    );
  }
}
