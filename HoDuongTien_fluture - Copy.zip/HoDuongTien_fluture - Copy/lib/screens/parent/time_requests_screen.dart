
import 'package:flutter/material.dart';

import '../../models/child_model.dart';
import '../../services/child_service.dart';
import '../../services/time_request_service.dart';

class TimeRequestsScreen extends StatefulWidget {
  final String token;

  const TimeRequestsScreen({
    super.key,
    required this.token,
  });

  @override
  State<TimeRequestsScreen> createState() =>
      _TimeRequestsScreenState();
}

class _TimeRequestsScreenState
    extends State<TimeRequestsScreen> {
  late final ChildService childService;
  late final TimeRequestService requestService;

  List<ChildModel> children = [];
  List<TimeRequestModel> requests = [];

  int? selectedChildId;
  int? reviewingId;

  bool loading = true;
  bool loadingRequests = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    childService = ChildService(token: widget.token);
    requestService =
        TimeRequestService(token: widget.token);
    loadChildren();
  }

  Future<void> loadChildren() async {
    try {
      final result = await childService.getChildren();

      if (!mounted) return;

      setState(() {
        children = result;
        selectedChildId =
        result.isEmpty ? null : result.first.id;
        loading = false;
      });

      if (selectedChildId != null) {
        await loadRequests();
      }
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
        loading = false;
      });
    }
  }

  Future<void> loadRequests() async {
    final childId = selectedChildId;
    if (childId == null) return;

    setState(() {
      loadingRequests = true;
      requests = [];
      errorMessage = null;
    });

    try {
      final result =
      await requestService.getRequests(childId);

      if (!mounted || selectedChildId != childId) return;

      setState(() {
        requests = result;
      });
    } catch (e) {
      if (!mounted || selectedChildId != childId) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted && selectedChildId == childId) {
        setState(() => loadingRequests = false);
      }
    }
  }

  Future<void> review(
      TimeRequestModel request,
      bool approve,
      ) async {
    setState(() => reviewingId = request.id);

    try {
      await requestService.reviewRequest(
        requestId: request.id,
        approve: approve,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            approve
                ? 'Đã duyệt yêu cầu'
                : 'Đã từ chối yêu cầu',
          ),
        ),
      );

      await loadRequests();
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Lỗi: $e')),
      );
    } finally {
      if (mounted) {
        setState(() => reviewingId = null);
      }
    }
  }

  String statusText(String status) {
    switch (status) {
      case 'Pending':
        return 'Đang chờ duyệt';
      case 'Approved':
        return 'Đã duyệt';
      case 'Rejected':
        return 'Đã từ chối';
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Yêu cầu thêm thời gian'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: loadingRequests ? null : loadRequests,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: loading
          ? const Center(
        child: CircularProgressIndicator(),
      )
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Duyệt yêu cầu của trẻ',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 20),

          if (children.isEmpty)
            const Text(
              'Chưa có hồ sơ trẻ.',
            )
          else
            DropdownButtonFormField<int>(
              initialValue: selectedChildId,
              decoration: const InputDecoration(
                labelText: 'Chọn trẻ',
                border: OutlineInputBorder(),
              ),
              items: children.map((child) {
                return DropdownMenuItem(
                  value: child.id,
                  child: Text(child.fullName),
                );
              }).toList(),
              onChanged: loadingRequests ||
                  reviewingId != null
                  ? null
                  : (id) {
                if (id == null) return;

                setState(() {
                  selectedChildId = id;
                });

                loadRequests();
              },
            ),

          const SizedBox(height: 20),

          if (loadingRequests)
            const Center(
              child: CircularProgressIndicator(),
            )
          else if (errorMessage != null)
            Text(
              errorMessage!,
              style: const TextStyle(color: Colors.red),
            )
          else if (requests.isEmpty && children.isNotEmpty)
              const Text('Chưa có yêu cầu nào.')
            else
              ...requests.map((request) {
                final pending =
                    request.status == 'Pending';

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Xin thêm '
                              '${request.requestedMinutes} phút',
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Lý do: ${request.reason}',
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Trạng thái: '
                              '${statusText(request.status)}',
                        ),
                        if (pending) ...[
                          const SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: reviewingId != null
                                      ? null
                                      : () => review(
                                    request,
                                    true,
                                  ),
                                  child: const Text('Duyệt'),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: OutlinedButton(
                                  onPressed: reviewingId != null
                                      ? null
                                      : () => review(
                                    request,
                                    false,
                                  ),
                                  child: const Text(
                                    'Từ chối',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              }),
        ],
      ),
    );
  }
}
