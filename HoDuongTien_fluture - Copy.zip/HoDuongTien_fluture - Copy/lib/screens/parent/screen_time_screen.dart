
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../models/child_model.dart';
import '../../services/child_service.dart';
import '../../services/screen_time_service.dart';

class ScreenTimeScreen extends StatefulWidget {
  final String token;

  const ScreenTimeScreen({
    super.key,
    required this.token,
  });

  @override
  State<ScreenTimeScreen> createState() =>
      _ScreenTimeScreenState();
}

class _ScreenTimeScreenState extends State<ScreenTimeScreen> {
  late final ChildService childService;
  late final ScreenTimeService screenTimeService;

  final TextEditingController minutesController =
  TextEditingController(text: '120');

  List<ChildModel> children = [];
  int? selectedChildId;

  bool loading = true;
  bool loadingRule = false;
  bool saving = false;
  bool isEnabled = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    childService = ChildService(token: widget.token);
    screenTimeService =
        ScreenTimeService(token: widget.token);
    loadChildren();
  }

  @override
  void dispose() {
    minutesController.dispose();
    super.dispose();
  }

  Future<void> loadChildren() async {
    try {
      final result = await childService.getChildren();

      if (!mounted) return;

      setState(() {
        children = result;
        selectedChildId =
        result.isEmpty ? null : result.first.id;
        loading = false;
      });

      if (selectedChildId != null) {
        await loadRule();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        errorMessage = e.toString();
      });
    }
  }

  Future<void> loadRule() async {
    final childId = selectedChildId;
    if (childId == null) return;

    setState(() {
      loadingRule = true;
      errorMessage = null;
    });

    try {
      final rule = await screenTimeService.getRule(childId);

      if (!mounted || selectedChildId != childId) return;

      setState(() {
        minutesController.text =
            rule.dailyLimitMinutes.toString();
        isEnabled = rule.isEnabled;
      });
    } catch (e) {
      if (!mounted || selectedChildId != childId) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted && selectedChildId == childId) {
        setState(() => loadingRule = false);
      }
    }
  }

  Future<void> saveRule() async {
    final childId = selectedChildId;
    final minutes =
    int.tryParse(minutesController.text.trim());

    if (childId == null) return;

    if (minutes == null ||
        minutes < 1 ||
        minutes > 1440) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Nhập giới hạn từ 1 đến 1440 phút.',
          ),
        ),
      );
      return;
    }

    setState(() {
      saving = true;
      errorMessage = null;
    });

    try {
      await screenTimeService.saveRule(
        childId: childId,
        dailyLimitMinutes: minutes,
        isEnabled: isEnabled,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Lưu giới hạn thành công'),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() => errorMessage = e.toString());
    } finally {
      if (mounted) {
        setState(() => saving = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quản lý thời gian'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: loading
          ? const Center(
        child: CircularProgressIndicator(),
      )
          : ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(
            Icons.timer,
            size: 75,
            color: Colors.orange,
          ),
          const SizedBox(height: 16),
          const Text(
            'Giới hạn thời gian sử dụng',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 24),

          if (children.isEmpty)
            const Text(
              'Chưa có hồ sơ trẻ. '
                  'Hãy thêm trẻ trước.',
              textAlign: TextAlign.center,
            )
          else ...[
            DropdownButtonFormField<int>(
              initialValue: selectedChildId,
              decoration: const InputDecoration(
                labelText: 'Chọn trẻ',
                border: OutlineInputBorder(),
              ),
              items: children.map((child) {
                return DropdownMenuItem(
                  value: child.id,
                  child: Text(child.fullName),
                );
              }).toList(),
              onChanged: saving || loadingRule
                  ? null
                  : (id) {
                if (id == null) return;
                setState(() {
                  selectedChildId = id;
                });
                loadRule();
              },
            ),

            const SizedBox(height: 20),

            if (loadingRule)
              const Center(
                child: CircularProgressIndicator(),
              )
            else ...[
              TextField(
                controller: minutesController,
                enabled: !saving,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                decoration: const InputDecoration(
                  labelText: 'Số phút mỗi ngày',
                  hintText: 'Ví dụ: 120',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.schedule),
                ),
              ),

              const SizedBox(height: 12),

              SwitchListTile(
                title: const Text(
                  'Bật giới hạn thời gian',
                ),
                subtitle: const Text(
                  'Phụ huynh có thể bật hoặc tắt quy tắc',
                ),
                value: isEnabled,
                onChanged: saving
                    ? null
                    : (value) {
                  setState(() {
                    isEnabled = value;
                  });
                },
              ),

              const SizedBox(height: 20),

              ElevatedButton.icon(
                onPressed: saving ? null : saveRule,
                icon: const Icon(Icons.save),
                label: Text(
                  saving
                      ? 'Đang lưu...'
                      : 'Lưu giới hạn',
                ),
              ),
            ],
          ],

          if (errorMessage != null) ...[
            const SizedBox(height: 20),
            Text(
              errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
          ],
        ],
      ),
    );
  }
}
