
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../models/child_model.dart';
import '../../services/child_service.dart';
import '../../services/qr_service.dart';

class PairingScreen extends StatefulWidget {
  final String token;

  const PairingScreen({
    super.key,
    required this.token,
  });

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> {
  late final ChildService childService;
  late final QrService qrService;

  List<ChildModel> children = [];
  int? selectedChildId;
  PairingCodeResult? pairing;

  bool loading = true;
  bool generating = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();

    childService = ChildService(token: widget.token);
    qrService = QrService(token: widget.token);

    loadChildren();
  }

  Future<void> loadChildren() async {
    try {
      final result = await childService.getChildren();

      if (!mounted) return;

      setState(() {
        children = result;
        selectedChildId = result.isEmpty ? null : result.first.id;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
        loading = false;
      });
    }
  }

  Future<void> generateQr() async {
    final childId = selectedChildId;
    if (childId == null) return;

    setState(() {
      generating = true;
      pairing = null;
      errorMessage = null;
    });

    try {
      final result = await qrService.generateCode(childId);

      if (!mounted) return;

      setState(() {
        pairing = result;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          generating = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentPairing = pairing;

    final isExpired = currentPairing != null &&
        DateTime.now().isAfter(currentPairing.expiresAt);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Ghép nối thiết bị'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(
            Icons.qr_code_2,
            size: 75,
            color: Colors.blue,
          ),
          const SizedBox(height: 15),
          const Text(
            'Tạo mã QR cho trẻ',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),

          if (children.isEmpty)
            const Text(
              'Chưa có hồ sơ trẻ. '
                  'Hãy thêm trẻ trước khi ghép nối.',
              textAlign: TextAlign.center,
            )
          else
            DropdownButtonFormField<int>(
              initialValue: selectedChildId,
              decoration: const InputDecoration(
                labelText: 'Chọn trẻ',
                border: OutlineInputBorder(),
              ),
              items: children.map((child) {
                return DropdownMenuItem<int>(
                  value: child.id,
                  child: Text(child.fullName),
                );
              }).toList(),
              onChanged: generating
                  ? null
                  : (value) {
                setState(() {
                  selectedChildId = value;
                  pairing = null;
                  errorMessage = null;
                });
              },
            ),

          const SizedBox(height: 20),

          ElevatedButton.icon(
            onPressed: generating ||
                selectedChildId == null
                ? null
                : generateQr,
            icon: const Icon(Icons.qr_code),
            label: Text(
              generating
                  ? 'Đang tạo mã...'
                  : 'Tạo mã QR',
            ),
          ),

          if (errorMessage != null) ...[
            const SizedBox(height: 16),
            Text(
              errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
          ],

          if (currentPairing != null) ...[
            const SizedBox(height: 25),

            if (isExpired)
              const Text(
                'Mã QR đã hết hạn. Hãy tạo mã mới.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.red),
              )
            else ...[
              Center(
                child: QrImageView(
                  data: currentPairing.code,
                  version: QrVersions.auto,
                  size: 240,
                  backgroundColor: Colors.white,
                ),
              ),

              const SizedBox(height: 15),

              const Text(
                'Dùng tài khoản Child trên thiết bị '
                    'của trẻ để quét mã QR này.',
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 10),

              Text(
                'Hết hạn lúc: '
                    '${currentPairing.expiresAt.toLocal().hour.toString().padLeft(2, '0')}:'
                    '${currentPairing.expiresAt.toLocal().minute.toString().padLeft(2, '0')}',
                textAlign: TextAlign.center,
              ),

              const Text(
                'Mã chỉ sử dụng một lần và có hiệu lực 5 phút.',
                textAlign: TextAlign.center,
              ),
            ],
          ],
        ],
      ),
    );
  }
}
