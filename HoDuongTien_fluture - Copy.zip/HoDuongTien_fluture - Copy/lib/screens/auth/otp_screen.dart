
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/auth_service.dart';
import '../admin/admin_dashboard.dart';
import '../parent/parent_dashboard.dart';
import '../child/child_dashboard.dart';

class OtpScreen extends StatefulWidget {
  final String email;

  const OtpScreen({
    super.key,
    required this.email,
  });

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final TextEditingController otpController =
  TextEditingController();

  final AuthService authService = AuthService();

  bool isLoading = false;
  String statusMessage = '';

  Future<void> verifyOtp() async {
    final otp = otpController.text.trim();

    if (!RegExp(r'^\d{6}$').hasMatch(otp)) {
      showMessage('Vui lòng nhập đúng 6 chữ số OTP');
      return;
    }

    setState(() {
      isLoading = true;
      statusMessage = 'Đang xác thực OTP...';
    });

    try {
      final result = await authService.verifyOtp(
        widget.email,
        otp,
      );

      if (!mounted) return;

      if (result['success'] != true) {
        final message = result['message']?.toString() ??
            'Mã OTP không hợp lệ hoặc đã hết hạn';

        setState(() {
          statusMessage = message;
        });

        showMessage(message);
        return;
      }

      final responseData = result['data'];

      if (responseData is! Map) {
        setState(() {
          statusMessage =
          'API không trả về thông tin tài khoản.';
        });
        return;
      }

      final data = Map<String, dynamic>.from(responseData);

      final role = data['role']
          ?.toString()
          .trim()
          .toLowerCase();

      final token = data['token']?.toString() ?? '';

      if (token.isEmpty) {
        setState(() {
          statusMessage = 'API không trả về JWT.';
        });
        return;
      }

      Widget dashboard;

      switch (role) {
        case 'admin':
          dashboard = const AdminDashboard();
          break;

        case 'parent':
          dashboard = ParentDashboard(
            token: token,
          );
          break;

        case 'child':
          dashboard = ChildDashboard(
            token: token,
          );
          break;

        default:
          setState(() {
            statusMessage =
            'Vai trò tài khoản không hợp lệ: '
                '${role ?? "trống"}';
          });
          return;
      }

      if (!mounted) return;

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => dashboard,
        ),
            (route) => false,
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        statusMessage = 'Không thể xác thực OTP.';
      });

      showMessage('Lỗi kết nối hoặc xác thực: $e');
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  @override
  void dispose() {
    otpController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Xác thực OTP'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 65),

              const Icon(
                Icons.mark_email_read,
                size: 90,
                color: Colors.blue,
              ),

              const SizedBox(height: 20),

              const Text(
                'Xác thực tài khoản KidSafe',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 23,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 16),

              Text(
                'Nhập mã OTP đã gửi đến:\n${widget.email}',
                textAlign: TextAlign.center,
              ),

              const SizedBox(height: 30),

              TextField(
                controller: otpController,
                enabled: !isLoading,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 6,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                ],
                decoration: const InputDecoration(
                  labelText: 'Mã OTP',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
                onSubmitted: (_) {
                  if (!isLoading) {
                    verifyOtp();
                  }
                },
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: isLoading ? null : verifyOtp,
                  child: isLoading
                      ? const SizedBox(
                    height: 22,
                    width: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                    ),
                  )
                      : const Text('Xác thực OTP'),
                ),
              ),

              const SizedBox(height: 20),

              if (statusMessage.isNotEmpty)
                Text(
                  statusMessage,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.blue,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
