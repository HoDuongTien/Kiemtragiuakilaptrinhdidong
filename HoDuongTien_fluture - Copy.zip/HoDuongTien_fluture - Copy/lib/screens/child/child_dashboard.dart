
import 'package:flutter/material.dart';

import '../../services/child_profile_service.dart';
import 'child_screen_time_screen.dart';
import 'child_time_request_screen.dart';
import 'child_location_screen.dart';
import 'qr_scanner_screen.dart';

class ChildDashboard extends StatefulWidget {
  final String token;

  const ChildDashboard({
    super.key,
    required this.token,
  });

  @override
  State<ChildDashboard> createState() =>
      _ChildDashboardState();
}

class _ChildDashboardState extends State<ChildDashboard> {
  late final ChildProfileService profileService;

  int? childId;
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();

    profileService = ChildProfileService(
      token: widget.token,
    );

    loadChildProfile();
  }

  Future<void> loadChildProfile() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final id = await profileService.getMyChildId();

      if (!mounted) return;

      setState(() {
        childId = id;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
        childId = null;
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
      ),
    );
  }

  // 1. XEM THỜI GIAN SỬ DỤNG
  void openScreenTime() {
    final id = childId;

    if (id == null) {
      showMessage(
        'Tài khoản chưa liên kết với hồ sơ trẻ.',
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChildScreenTimeScreen(
          token: widget.token,
          childId: id,
        ),
      ),
    );
  }

  // 2. XIN THÊM THỜI GIAN
  void openTimeRequests() {
    final id = childId;

    if (id == null) {
      showMessage(
        'Tài khoản chưa liên kết với hồ sơ trẻ.',
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChildTimeRequestScreen(
          token: widget.token,
          childId: id,
        ),
      ),
    );
  }

  // 3. CHIA SẺ VỊ TRÍ GPS
  void openChildLocation() {
    final id = childId;

    if (id == null) {
      showMessage(
        'Tài khoản chưa liên kết với hồ sơ trẻ.',
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChildLocationScreen(
          token: widget.token,
          childId: id,
        ),
      ),
    );
  }

  // 4. GHÉP NỐI THIẾT BỊ BẰNG QR
  void openQrScanner() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QrScannerScreen(
          token: widget.token,
        ),
      ),
    ).then((_) {
      if (mounted) {
        loadChildProfile();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KidSafe - Trẻ em'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: isLoading ? null : loadChildProfile,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),

      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SizedBox(height: 20),

          const Icon(
            Icons.child_friendly,
            size: 85,
            color: Colors.blue,
          ),

          const SizedBox(height: 16),

          const Center(
            child: Text(
              'Chào mừng đến KidSafe!',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),

          const SizedBox(height: 8),

          const Center(
            child: Text(
              'Ứng dụng bảo vệ và kết nối gia đình',
              style: TextStyle(
                fontSize: 15,
                color: Colors.grey,
              ),
            ),
          ),

          const SizedBox(height: 20),

          // THÔNG TIN HỒ SƠ TRẺ
          if (isLoading)
            const Center(
              child: CircularProgressIndicator(),
            )
          else if (errorMessage != null)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Icon(
                      Icons.warning_amber,
                      color: Colors.orange,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      errorMessage!,
                      textAlign: TextAlign.center,
                    ),
                    TextButton(
                      onPressed: loadChildProfile,
                      child: const Text('Thử lại'),
                    ),
                  ],
                ),
              ),
            )
          else
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.verified_user,
                  color: Colors.green,
                ),
                title: const Text(
                  'Hồ sơ trẻ đã được liên kết',
                ),
                subtitle: Text(
                  'Mã hồ sơ: $childId',
                ),
              ),
            ),

          const SizedBox(height: 20),

          // 1. THỜI GIAN SỬ DỤNG
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.timer,
                color: Colors.orange,
              ),
              title: const Text(
                'Thời gian sử dụng',
              ),
              subtitle: const Text(
                'Xem giới hạn do phụ huynh thiết lập',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: isLoading ? null : openScreenTime,
            ),
          ),

          // 2. XIN THÊM THỜI GIAN
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.add_alarm,
                color: Colors.green,
              ),
              title: const Text(
                'Xin thêm thời gian',
              ),
              subtitle: const Text(
                'Gửi yêu cầu và xem trạng thái duyệt',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: isLoading ? null : openTimeRequests,
            ),
          ),

          // 3. CHIA SẺ VỊ TRÍ GPS
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.location_on,
                color: Colors.red,
              ),
              title: const Text(
                'Chia sẻ vị trí GPS',
              ),
              subtitle: const Text(
                'Gửi vị trí hiện tại cho phụ huynh',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: isLoading ? null : openChildLocation,
            ),
          ),

          // 4. GHÉP NỐI VỚI PHỤ HUYNH
          Card(
            child: ListTile(
              leading: const Icon(
                Icons.qr_code_scanner,
                color: Colors.blue,
              ),
              title: const Text(
                'Ghép nối với phụ huynh',
              ),
              subtitle: const Text(
                'Quét mã QR để liên kết thiết bị',
              ),
              trailing: const Icon(
                Icons.chevron_right,
              ),
              onTap: openQrScanner,
            ),
          ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}
