
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../services/qr_service.dart';

class QrScannerScreen extends StatefulWidget {
  final String token;

  const QrScannerScreen({
    super.key,
    required this.token,
  });

  @override
  State<QrScannerScreen> createState() =>
      _QrScannerScreenState();
}

class _QrScannerScreenState extends State<QrScannerScreen> {
  late final QrService qrService;
  final MobileScannerController scannerController =
  MobileScannerController();

  bool processing = false;

  @override
  void initState() {
    super.initState();
    qrService = QrService(token: widget.token);
  }

  @override
  void dispose() {
    scannerController.dispose();
    super.dispose();
  }

  Future<void> pairDevice(String code) async {
    if (processing) return;

    setState(() => processing = true);
    await scannerController.stop();

    if (!mounted) return;

    final nameController = TextEditingController(
      text: 'Thiết bị của trẻ',
    );

    final deviceName = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Xác nhận ghép nối'),
        content: TextField(
          controller: nameController,
          maxLength: 100,
          decoration: const InputDecoration(
            labelText: 'Tên thiết bị',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(dialogContext),
            child: const Text('Hủy'),
          ),
          ElevatedButton(
            onPressed: () {
              final name = nameController.text.trim();
              if (name.isNotEmpty) {
                Navigator.pop(dialogContext, name);
              }
            },
            child: const Text('Ghép nối'),
          ),
        ],
      ),
    );

    if (!mounted) return;

    if (deviceName == null) {
      setState(() => processing = false);
      await scannerController.start();
      return;
    }

    try {
      final message = await qrService.pairDevice(
        code: code,
        deviceName: deviceName,
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );

      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Ghép nối thất bại: $e'),
        ),
      );

      setState(() => processing = false);
      await scannerController.start();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Quét mã QR'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: scannerController,
            onDetect: (capture) {
              if (processing) return;

              final barcodes = capture.barcodes;
              if (barcodes.isEmpty) return;

              final code = barcodes.first.rawValue;

              if (code != null && code.isNotEmpty) {
                pairDevice(code);
              }
            },
          ),

          const Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.all(30),
              child: Text(
                'Đưa mã QR của phụ huynh vào khung camera',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  backgroundColor: Colors.black54,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
