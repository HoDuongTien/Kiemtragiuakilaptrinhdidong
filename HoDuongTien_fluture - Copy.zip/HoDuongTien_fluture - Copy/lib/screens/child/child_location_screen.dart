
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../../services/child_gps_service.dart';

class ChildLocationScreen extends StatefulWidget {
  final String token;
  final int childId;

  const ChildLocationScreen({
    super.key,
    required this.token,
    required this.childId,
  });

  @override
  State<ChildLocationScreen> createState() =>
      _ChildLocationScreenState();
}

class _ChildLocationScreenState
    extends State<ChildLocationScreen> {
  late final ChildGpsService gpsService;

  Position? lastPosition;
  DateTime? lastSharedAt;

  bool isSharing = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();

    gpsService = ChildGpsService(
      token: widget.token,
    );
  }

  Future<void> shareLocation() async {
    if (isSharing) return;

    setState(() {
      isSharing = true;
      errorMessage = null;
    });

    try {
      final position = await gpsService.shareLocation(
        widget.childId,
      );

      if (!mounted) return;

      setState(() {
        lastPosition = position;
        lastSharedAt = DateTime.now();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Đã chia sẻ vị trí thành công với phụ huynh!',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Không thể chia sẻ vị trí: $e'),
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          isSharing = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chia sẻ vị trí GPS'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 25),

          const Icon(
            Icons.location_on,
            size: 90,
            color: Colors.red,
          ),

          const SizedBox(height: 20),

          const Text(
            'Chia sẻ vị trí với phụ huynh',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 16),

          const Text(
            'Nhấn nút bên dưới để lấy vị trí hiện tại '
                'và gửi đến tài khoản phụ huynh đã liên kết.',
            textAlign: TextAlign.center,
          ),

          const SizedBox(height: 30),

          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: isSharing ? null : shareLocation,
              icon: const Icon(Icons.my_location),
              label: Text(
                isSharing
                    ? 'Đang lấy và gửi vị trí...'
                    : 'Chia sẻ vị trí hiện tại',
              ),
            ),
          ),

          if (isSharing) ...[
            const SizedBox(height: 20),
            const Center(
              child: CircularProgressIndicator(),
            ),
          ],

          if (errorMessage != null) ...[
            const SizedBox(height: 20),
            Text(
              errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.red,
              ),
            ),
          ],

          if (lastPosition != null) ...[
            const SizedBox(height: 30),

            const Text(
              'Vị trí vừa chia sẻ',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 12),

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Vĩ độ: '
                          '${lastPosition!.latitude.toStringAsFixed(6)}',
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Kinh độ: '
                          '${lastPosition!.longitude.toStringAsFixed(6)}',
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Độ chính xác: '
                          '${lastPosition!.accuracy.toStringAsFixed(1)} m',
                    ),
                    if (lastSharedAt != null) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Thời gian gửi: '
                            '${lastSharedAt!.hour.toString().padLeft(2, '0')}:'
                            '${lastSharedAt!.minute.toString().padLeft(2, '0')}',
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],

          const SizedBox(height: 20),

          const Text(
            'Lưu ý: Vị trí chỉ được gửi khi bạn nhấn '
                'nút chia sẻ. Ứng dụng không tự theo dõi '
                'vị trí khi chạy nền.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
