
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../services/time_request_service.dart';

class ChildTimeRequestScreen extends StatefulWidget {
  final String token;
  final int childId;

  const ChildTimeRequestScreen({
    super.key,
    required this.token,
    required this.childId,
  });

  @override
  State<ChildTimeRequestScreen> createState() =>
      _ChildTimeRequestScreenState();
}

class _ChildTimeRequestScreenState
    extends State<ChildTimeRequestScreen> {
  late final TimeRequestService requestService;

  final minutesController =
  TextEditingController(text: '30');
  final reasonController = TextEditingController();

  List<TimeRequestModel> requests = [];

  bool isLoading = true;
  bool isSending = false;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    requestService = TimeRequestService(
      token: widget.token,
    );
    loadRequests();
  }

  @override
  void dispose() {
    minutesController.dispose();
    reasonController.dispose();
    super.dispose();
  }

  Future<void> loadRequests() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await requestService.getRequests(
        widget.childId,
      );

      if (!mounted) return;

      setState(() {
        requests = result;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> sendRequest() async {
    final minutes =
    int.tryParse(minutesController.text.trim());
    final reason = reasonController.text.trim();

    if (minutes == null ||
        minutes < 1 ||
        minutes > 1440) {
      showMessage('Nhập số phút từ 1 đến 1440.');
      return;
    }

    if (reason.length < 2 || reason.length > 500) {
      showMessage(
        'Lý do phải có từ 2 đến 500 ký tự.',
      );
      return;
    }

    setState(() {
      isSending = true;
      errorMessage = null;
    });

    try {
      await requestService.sendRequest(
        childId: widget.childId,
        requestedMinutes: minutes,
        reason: reason,
      );

      if (!mounted) return;

      reasonController.clear();

      showMessage('Đã gửi yêu cầu đến phụ huynh.');

      await loadRequests();
    } catch (e) {
      if (!mounted) return;

      showMessage('Gửi yêu cầu thất bại: $e');
    } finally {
      if (mounted) {
        setState(() {
          isSending = false;
        });
      }
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  String getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'Đang chờ duyệt';
      case 'approved':
        return 'Đã duyệt';
      case 'rejected':
        return 'Đã từ chối';
      default:
        return status;
    }
  }

  Color getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'approved':
        return Colors.green;
      case 'rejected':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Xin thêm thời gian'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: isLoading ? null : loadRequests,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Icon(
            Icons.add_alarm,
            size: 75,
            color: Colors.orange,
          ),

          const SizedBox(height: 16),

          const Text(
            'Gửi yêu cầu thêm thời gian',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 24),

          TextField(
            controller: minutesController,
            enabled: !isSending,
            keyboardType: TextInputType.number,
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
            ],
            decoration: const InputDecoration(
              labelText: 'Số phút muốn xin thêm',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.timer),
            ),
          ),

          const SizedBox(height: 16),

          TextField(
            controller: reasonController,
            enabled: !isSending,
            maxLines: 3,
            maxLength: 500,
            decoration: const InputDecoration(
              labelText: 'Lý do xin thêm thời gian',
              hintText: 'Ví dụ: Con muốn học thêm 30 phút',
              border: OutlineInputBorder(),
            ),
          ),

          const SizedBox(height: 16),

          ElevatedButton.icon(
            onPressed: isSending ? null : sendRequest,
            icon: const Icon(Icons.send),
            label: Text(
              isSending
                  ? 'Đang gửi...'
                  : 'Gửi yêu cầu',
            ),
          ),

          const SizedBox(height: 30),

          const Text(
            'Lịch sử yêu cầu',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 12),

          if (isLoading)
            const Center(
              child: CircularProgressIndicator(),
            )
          else if (errorMessage != null)
            Text(
              errorMessage!,
              style: const TextStyle(color: Colors.red),
            )
          else if (requests.isEmpty)
              const Text('Chưa có yêu cầu nào.')
            else
              ...requests.map((request) {
                return Card(
                  child: ListTile(
                    leading: Icon(
                      Icons.access_time,
                      color: getStatusColor(
                        request.status,
                      ),
                    ),
                    title: Text(
                      'Xin thêm '
                          '${request.requestedMinutes} phút',
                    ),
                    subtitle: Text(
                      'Lý do: ${request.reason}\n'
                          'Trạng thái: '
                          '${getStatusText(request.status)}',
                    ),
                    isThreeLine: true,
                  ),
                );
              }),
        ],
      ),
    );
  }
}
