
import 'package:flutter/material.dart';

import '../../services/screen_time_service.dart';

class ChildScreenTimeScreen extends StatefulWidget {
  final String token;
  final int childId;

  const ChildScreenTimeScreen({
    super.key,
    required this.token,
    required this.childId,
  });

  @override
  State<ChildScreenTimeScreen> createState() =>
      _ChildScreenTimeScreenState();
}

class _ChildScreenTimeScreenState
    extends State<ChildScreenTimeScreen> {
  late final ScreenTimeService screenTimeService;

  ScreenTimeRuleModel? rule;
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    screenTimeService =
        ScreenTimeService(token: widget.token);
    loadRule();
  }

  Future<void> loadRule() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });

    try {
      final result = await screenTimeService.getRule(
        widget.childId,
      );

      if (!mounted) return;

      setState(() {
        rule = result;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        errorMessage = e.toString();
      });
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentRule = rule;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Thời gian sử dụng'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            onPressed: isLoading ? null : loadRule,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : errorMessage != null
          ? Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(
            errorMessage!,
            textAlign: TextAlign.center,
          ),
        ),
      )
          : currentRule == null
          ? const Center(
        child: Text('Chưa có dữ liệu thời gian.'),
      )
          : Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment:
            MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.timer,
                size: 90,
                color: Colors.orange,
              ),
              const SizedBox(height: 20),
              const Text(
                'Giới hạn thời gian mỗi ngày',
                style: TextStyle(fontSize: 20),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                '${currentRule.dailyLimitMinutes} phút',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                currentRule.isEnabled
                    ? 'Đang áp dụng giới hạn'
                    : 'Phụ huynh đã tắt giới hạn',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              const Text(
                'Đây là giới hạn do phụ huynh '
                    'thiết lập, chưa phải số phút '
                    'còn lại thực tế.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
