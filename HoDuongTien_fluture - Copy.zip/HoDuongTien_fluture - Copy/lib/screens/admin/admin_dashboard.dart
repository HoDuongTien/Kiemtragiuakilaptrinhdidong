
import 'package:flutter/material.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('KidSafe - Quản trị viên'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          Icon(
            Icons.admin_panel_settings,
            size: 85,
            color: Colors.blue,
          ),
          SizedBox(height: 16),
          Center(
            child: Text(
              'Trang quản trị KidSafe',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(height: 25),
          Card(
            child: ListTile(
              leading: Icon(Icons.people),
              title: Text('Quản lý người dùng'),
              subtitle: Text('Danh sách tài khoản'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.devices),
              title: Text('Quản lý thiết bị'),
            ),
          ),
          Card(
            child: ListTile(
              leading: Icon(Icons.bar_chart),
              title: Text('Thống kê hệ thống'),
            ),
          ),
        ],
      ),
    );
  }
}
