
import 'dart:convert';

import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class ScreenTimeRuleModel {
  final int childId;
  final int dailyLimitMinutes;
  final bool isEnabled;
  final bool isConfigured;

  const ScreenTimeRuleModel({
    required this.childId,
    required this.dailyLimitMinutes,
    required this.isEnabled,
    required this.isConfigured,
  });

  factory ScreenTimeRuleModel.fromJson(
      Map<String, dynamic> json,
      ) {
    return ScreenTimeRuleModel(
      childId: (json['childId'] as num).toInt(),
      dailyLimitMinutes:
      (json['dailyLimitMinutes'] as num).toInt(),
      isEnabled: json['isEnabled'] == true,
      isConfigured: json['isConfigured'] != false,
    );
  }
}

class ScreenTimeService {
  final String token;

  ScreenTimeService({required this.token});

  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<ScreenTimeRuleModel> getRule(int childId) async {
    final response = await http.get(
      Uri.parse(
        '${ApiConfig.baseUrl}/screen-time/child/$childId',
      ),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Không lấy được giới hạn thời gian '
            '(${response.statusCode}): ${response.body}',
      );
    }

    return ScreenTimeRuleModel.fromJson(
      Map<String, dynamic>.from(
        jsonDecode(response.body) as Map,
      ),
    );
  }

  Future<void> saveRule({
    required int childId,
    required int dailyLimitMinutes,
    required bool isEnabled,
  }) async {
    if (dailyLimitMinutes < 1 ||
        dailyLimitMinutes > 1440) {
      throw ArgumentError(
        'Giới hạn phải từ 1 đến 1440 phút.',
      );
    }

    final response = await http.put(
      Uri.parse(
        '${ApiConfig.baseUrl}/screen-time/child/$childId',
      ),
      headers: headers,
      body: jsonEncode({
        'dailyLimitMinutes': dailyLimitMinutes,
        'isEnabled': isEnabled,
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Không lưu được giới hạn '
            '(${response.statusCode}): ${response.body}',
      );
    }
  }
}
