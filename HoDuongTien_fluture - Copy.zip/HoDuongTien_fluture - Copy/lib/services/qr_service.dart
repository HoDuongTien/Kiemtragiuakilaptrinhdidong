
import 'dart:convert';

import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class PairingCodeResult {
  final int childId;
  final String code;
  final DateTime expiresAt;

  PairingCodeResult({
    required this.childId,
    required this.code,
    required this.expiresAt,
  });

  factory PairingCodeResult.fromJson(
      Map<String, dynamic> json,
      ) {
    return PairingCodeResult(
      childId: (json['childId'] as num).toInt(),
      code: json['code'].toString(),
      expiresAt: DateTime.parse(
        json['expiresAt'].toString(),
      ),
    );
  }
}

class QrService {
  final String token;

  QrService({required this.token});

  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<PairingCodeResult> generateCode(int childId) async {
    final response = await http.post(
      Uri.parse(
        '${ApiConfig.baseUrl}/qr/child/$childId/generate',
      ),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    final data = _decodeResponse(response);

    if (response.statusCode != 200) {
      throw Exception(
        data['message'] ?? 'Không tạo được mã QR',
      );
    }

    return PairingCodeResult.fromJson(data);
  }

  Future<String> pairDevice({
    required String code,
    required String deviceName,
    String? deviceModel,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/qr/pair'),
      headers: headers,
      body: jsonEncode({
        'code': code,
        'deviceName': deviceName,
        'deviceModel': deviceModel,
      }),
    ).timeout(const Duration(seconds: 20));

    final data = _decodeResponse(response);

    if (response.statusCode != 200) {
      throw Exception(
        data['message'] ?? 'Ghép nối thất bại',
      );
    }

    return data['message']?.toString() ??
        'Ghép nối thành công';
  }

  Map<String, dynamic> _decodeResponse(
      http.Response response,
      ) {
    final decoded = jsonDecode(response.body);

    if (decoded is! Map) {
      throw const FormatException(
        'Dữ liệu API không đúng định dạng',
      );
    }

    return Map<String, dynamic>.from(decoded);
  }
}
