
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/api_config.dart';

class AuthService {
  Future<Map<String, dynamic>> register(
      String fullName,
      String email,
      String password,
      ) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/Auth/register'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'fullName': fullName,
        'email': email,
        'password': password,
      }),
    ).timeout(const Duration(seconds: 20));

    return _parseResponse(response);
  }

  Future<Map<String, dynamic>> login(
      String email,
      String password,
      ) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/Auth/login'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'email': email,
        'password': password,
      }),
    ).timeout(const Duration(seconds: 20));

    return _parseResponse(response);
  }

  Future<Map<String, dynamic>> verifyOtp(
      String email,
      String otpCode,
      ) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/Auth/verify-otp'),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'email': email,
        'otpCode': otpCode,
      }),
    ).timeout(const Duration(seconds: 20));

    return _parseResponse(response);
  }

  Map<String, dynamic> _parseResponse(
      http.Response response,
      ) {
    final data = jsonDecode(response.body);

    if (data is! Map<String, dynamic>) {
      throw const FormatException(
        'Phản hồi API không đúng định dạng JSON.',
      );
    }

    return {
      ...data,
      'success': response.statusCode >= 200 &&
          response.statusCode < 300 &&
          data['success'] != false,
      'statusCode': response.statusCode,
    };
  }
}
