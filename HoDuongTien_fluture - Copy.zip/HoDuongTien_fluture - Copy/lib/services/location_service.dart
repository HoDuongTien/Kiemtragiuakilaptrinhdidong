
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class ChildLocationModel {
  final int id;
  final int childId;
  final double latitude;
  final double longitude;
  final DateTime recordedAt;

  const ChildLocationModel({
    required this.id,
    required this.childId,
    required this.latitude,
    required this.longitude,
    required this.recordedAt,
  });

  factory ChildLocationModel.fromJson(
      Map<String, dynamic> json,
      ) {
    return ChildLocationModel(
      id: (json['id'] as num).toInt(),
      childId: (json['childId'] as num).toInt(),
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      recordedAt: DateTime.parse(
        json['recordedAt'].toString(),
      ),
    );
  }
}

class LocationService {
  final String token;

  LocationService({required this.token});

  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<ChildLocationModel> getLatestLocation(
      int childId,
      ) async {
    final response = await http.get(
      Uri.parse(
        '${ApiConfig.baseUrl}/locations/child/'
            '$childId/latest',
      ),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return ChildLocationModel.fromJson(
        Map<String, dynamic>.from(data as Map),
      );
    }

    if (response.statusCode == 404) {
      throw Exception(
        'Chưa có vị trí GPS hoặc không tìm thấy trẻ.',
      );
    }

    throw Exception(
      'Không lấy được vị trí (${response.statusCode})',
    );
  }

  Future<List<ChildLocationModel>> getLocationHistory(
      int childId,
      ) async {
    final response = await http.get(
      Uri.parse(
        '${ApiConfig.baseUrl}/locations/child/'
            '$childId/history?take=50',
      ),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Không lấy được lịch sử (${response.statusCode})',
      );
    }

    final data = jsonDecode(response.body);
    final locations = data['locations'] as List<dynamic>;

    return locations.map((item) {
      return ChildLocationModel.fromJson(
        Map<String, dynamic>.from(item as Map),
      );
    }).toList();
  }
}
