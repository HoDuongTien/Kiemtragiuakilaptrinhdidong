
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class ChildProfileService {
  final String token;

  ChildProfileService({required this.token});

  Future<int> getMyChildId() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/dashboard/child'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      String message = 'Không lấy được hồ sơ trẻ';

      try {
        final data = jsonDecode(response.body);
        if (data is Map && data['message'] != null) {
          message = data['message'].toString();
        }
      } catch (_) {}

      throw Exception(
        '$message (${response.statusCode})',
      );
    }

    final decoded = jsonDecode(response.body);

    if (decoded is! Map || decoded['child'] is! Map) {
      throw const FormatException(
        'API không trả về hồ sơ trẻ hợp lệ.',
      );
    }

    final child = Map<String, dynamic>.from(
      decoded['child'] as Map,
    );

    final childId = child['id'];

    if (childId is! num) {
      throw const FormatException(
        'Không tìm thấy childId trong phản hồi API.',
      );
    }

    return childId.toInt();
  }
}
