
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/api_config.dart';
import '../models/child_model.dart';

class ChildService {
  final String token;

  ChildService({required this.token});

  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<List<ChildModel>> getChildren() async {
    final response = await http.get(
      Uri.parse('${ApiConfig.baseUrl}/Child'),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Không tải được danh sách trẻ (${response.statusCode})',
      );
    }

    final data = jsonDecode(response.body) as List<dynamic>;

    return data
        .map((item) => ChildModel.fromJson(
      Map<String, dynamic>.from(item as Map),
    ))
        .toList();
  }

  Future<void> addChild({
    required String fullName,
    DateTime? dateOfBirth,
    String? gender,
  }) async {
    final response = await http.post(
      Uri.parse('${ApiConfig.baseUrl}/Child'),
      headers: headers,
      body: jsonEncode({
        'fullName': fullName,
        'dateOfBirth': dateOfBirth?.toIso8601String(),
        'gender': gender,
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 201) {
      throw Exception(
        'Thêm trẻ thất bại (${response.statusCode}): '
            '${response.body}',
      );
    }
  }

  Future<void> updateChild({
    required int id,
    required String fullName,
    DateTime? dateOfBirth,
    String? gender,
  }) async {
    final response = await http.put(
      Uri.parse('${ApiConfig.baseUrl}/Child/$id'),
      headers: headers,
      body: jsonEncode({
        'fullName': fullName,
        'dateOfBirth': dateOfBirth?.toIso8601String(),
        'gender': gender,
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Cập nhật thất bại (${response.statusCode}): '
            '${response.body}',
      );
    }
  }

  Future<void> deleteChild(int id) async {
    final response = await http.delete(
      Uri.parse('${ApiConfig.baseUrl}/Child/$id'),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Xóa trẻ thất bại (${response.statusCode}): '
            '${response.body}',
      );
    }
  }
}
