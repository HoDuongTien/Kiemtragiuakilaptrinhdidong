
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class TimeRequestModel {
  final int id;
  final int childId;
  final int requestedMinutes;
  final String reason;
  final String status;
  final DateTime createdAt;

  const TimeRequestModel({
    required this.id,
    required this.childId,
    required this.requestedMinutes,
    required this.reason,
    required this.status,
    required this.createdAt,
  });

  factory TimeRequestModel.fromJson(
      Map<String, dynamic> json,
      ) {
    return TimeRequestModel(
      id: (json['id'] as num).toInt(),
      childId: (json['childId'] as num).toInt(),
      requestedMinutes:
      (json['requestedMinutes'] as num).toInt(),
      reason: json['reason']?.toString() ?? '',
      status: json['status']?.toString() ?? '',
      createdAt: DateTime.parse(
        json['createdAt'].toString(),
      ),
    );
  }
}

class TimeRequestService {
  final String token;

  TimeRequestService({required this.token});

  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  };

  Future<List<TimeRequestModel>> getRequests(
      int childId,
      ) async {
    final response = await http.get(
      Uri.parse(
        '${ApiConfig.baseUrl}/time-requests/child/$childId',
      ),
      headers: headers,
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Không lấy được yêu cầu (${response.statusCode}): '
            '${response.body}',
      );
    }

    final decoded = jsonDecode(response.body) as List;

    return decoded.map((item) {
      return TimeRequestModel.fromJson(
        Map<String, dynamic>.from(item as Map),
      );
    }).toList();
  }

  Future<void> sendRequest({
    required int childId,
    required int requestedMinutes,
    required String reason,
  }) async {
    if (requestedMinutes < 1 ||
        requestedMinutes > 1440 ||
        reason.trim().length < 2 ||
        reason.trim().length > 500) {
      throw ArgumentError('Thông tin yêu cầu không hợp lệ.');
    }

    final response = await http.post(
      Uri.parse(
        '${ApiConfig.baseUrl}/time-requests/child/$childId',
      ),
      headers: headers,
      body: jsonEncode({
        'requestedMinutes': requestedMinutes,
        'reason': reason.trim(),
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Gửi yêu cầu thất bại (${response.statusCode}): '
            '${response.body}',
      );
    }
  }

  Future<void> reviewRequest({
    required int requestId,
    required bool approve,
  }) async {
    final response = await http.put(
      Uri.parse(
        '${ApiConfig.baseUrl}/time-requests/'
            '$requestId/review',
      ),
      headers: headers,
      body: jsonEncode({
        'decision': approve ? 'Approved' : 'Rejected',
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Xử lý yêu cầu thất bại (${response.statusCode}): '
            '${response.body}',
      );
    }
  }
}
