
import 'dart:convert';

import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import '../config/api_config.dart';

class ChildGpsService {
  final String token;

  ChildGpsService({required this.token});

  Future<Position> getCurrentPosition() async {
    final serviceEnabled =
    await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      throw Exception(
        'GPS đang tắt. Hãy bật dịch vụ vị trí trên thiết bị.',
      );
    }

    var permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }

    if (permission == LocationPermission.denied) {
      throw Exception(
        'Bạn chưa cấp quyền truy cập vị trí.',
      );
    }

    if (permission == LocationPermission.deniedForever) {
      throw Exception(
        'Quyền vị trí đã bị từ chối vĩnh viễn. '
            'Hãy bật quyền trong Cài đặt ứng dụng.',
      );
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: 20),
      ),
    );
  }

  Future<Position> shareLocation(int childId) async {
    final position = await getCurrentPosition();

    final response = await http.post(
      Uri.parse(
        '${ApiConfig.baseUrl}/locations/child/$childId',
      ),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'latitude': position.latitude,
        'longitude': position.longitude,
      }),
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode != 200) {
      throw Exception(
        'Gửi vị trí thất bại '
            '(${response.statusCode}): ${response.body}',
      );
    }

    return position;
  }
}
