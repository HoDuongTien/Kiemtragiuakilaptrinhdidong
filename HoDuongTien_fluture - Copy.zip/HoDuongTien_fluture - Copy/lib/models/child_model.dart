
class ChildModel {
  final int id;
  final String fullName;
  final DateTime? dateOfBirth;
  final String? gender;
  final int parentId;

  const ChildModel({
    required this.id,
    required this.fullName,
    this.dateOfBirth,
    this.gender,
    required this.parentId,
  });

  factory ChildModel.fromJson(Map<String, dynamic> json) {
    return ChildModel(
      id: (json['id'] as num).toInt(),
      fullName: json['fullName']?.toString() ?? '',
      dateOfBirth: json['dateOfBirth'] == null
          ? null
          : DateTime.tryParse(json['dateOfBirth'].toString()),
      gender: json['gender']?.toString(),
      parentId: (json['parentId'] as num).toInt(),
    );
  }
}
